#include <stdio.h>

// Câu 1
// Hàm nhập ma trận
void inputMatrix(int matrix[][100], int rows, int cols) {
    printf("Enter elements of the matrix:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("Element [%d][%d]: ", i, j);
            scanf("%d", &matrix[i][j]);
        }
    }
}

// Câu 2
// Hàm xuất ma trận
void printMatrix(int matrix[][100], int rows, int cols) {
    printf("The matrix is:\n");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

// Câu 3
// Hàm kiểm tra ma trận có đối xứng hay không
int isSymmetricMatrix(int matrix[][100], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (matrix[i][j] != matrix[j][i]) {
                return 0; // Không đối xứng
            }
        }
    }
    return 1; // Đối xứng
}

// Câu 4
// Hàm main để thực hiện 3 hàm trên.
int main() {
    int matrix[100][100];
    int rows, cols;

    printf("Enter the number of rows and columns of the matrix: ");
    scanf("%d %d", &rows, &cols);

    if (rows != cols) {
        printf("The matrix is not square, so it cannot be symmetric.\n");
        return 1;
    }

    // Nhập ma trận
    inputMatrix(matrix, rows, cols);

    // Xuất ma trận
    printMatrix(matrix, rows, cols);

    // Kiểm tra ma trận có đối xứng hay không
    if (isSymmetricMatrix(matrix, rows)) {
        printf("The matrix is symmetric.\n");
    } else {
        printf("The matrix is not symmetric.\n");
    }

    return 0;
}
