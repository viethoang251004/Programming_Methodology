#include <stdio.h>
#include <string.h>

int main() {
    char a[100];
    int i;
    int p=0;
    printf("Nhap chuoi: ");
    fgets(a, sizeof(a), stdin);
    int count = 0;
    char *ntb = strtok(a, " ");
    int ntb_word[100] = {0};
    while (ntb != NULL) {
        // int p = 0; // chưa khai báo biến n và p và lvalue required as left operand of assignment
        for (i = 0; i < strlen(ntb); i++) {
            if (ntb[i] == ' ') {
                p = 1; // chưa khai báo biến p
            }
            break;
        }
    }
    while (!p) { // chưa khai báo biến p
        ntb_word[a[strlen(ntb)]/*)*/]++; // thiếu dấu ) và ghi a ở trước strlen là sai vì called object ‘a’ is not a function or function pointer
        ntb = strtok(NULL, ' ');
    }
    printf("So tu lap lai hon 2 lan: ");
    for (i = 0; i < strlen(ntb_word); i++) {
        if (ntb_word[i] >= 2) {
            count++;
        }
        printf("%d", count);
    }
    return 0;
}