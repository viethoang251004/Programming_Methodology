#include <stdio.h>
#include <string.h>
#include <ctype.h>

int countWords(const char *str) {
    int state = 0; // 0 means outside a word, 1 means inside a word
    int wordCount = 0;
    while (*str) {
        if (isspace(*str)) {
            state = 0;
        } else if (state == 0) {
            state = 1;
            ++wordCount;
        }
        ++str;
    }
    return wordCount;
}

void normalizeString(char *str) {
    int state = 0; // 0 means outside a word, 1 means inside a word
    char *ptr = str;
    while (*ptr) {
        if (isspace(*ptr)) {
            state = 0;
        } else if (state == 0) {
            *ptr = toupper(*ptr);
            state = 1;
        } else {
            *ptr = tolower(*ptr);
        }
        ++ptr;
    }
}

int countDuplicateWords(const char *str) {
    char words[100][100];
    int wordCount = 0;
    int duplicateCount = 0;
    char tempStr[1000];
    strcpy(tempStr, str);
    // Split the string into words
    char *word = strtok(tempStr, " \t\n");
    while (word != NULL) {
        strcpy(words[wordCount++], word);
        word = strtok(NULL, " \t\n");
    }
    // Count duplicate words
    for (int i = 0; i < wordCount; i++) {
        int count = 1;
        for (int j = i + 1; j < wordCount; j++) {
            if (strcasecmp(words[i], words[j]) == 0) {
                count++;
                // Remove duplicate word
                for (int k = j; k < wordCount - 1; k++) {
                    strcpy(words[k], words[k + 1]);
                }
                wordCount--;
                j--;
            }
        }
        if (count > 1) {
            duplicateCount++;
        }
    }
    return duplicateCount;
}

int main() {
    char str[1000];
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    // Remove the newline character at the end if present
    str[strcspn(str, "\n")] = '\0';
    int wordCount = countWords(str);
    printf("Number of words: %d\n", wordCount);
    normalizeString(str);
    printf("Normalized string: %s\n", str);
    int duplicateCount = countDuplicateWords(str);
    printf("Number of words that appear more than once: %d\n", duplicateCount);
    return 0;
}
