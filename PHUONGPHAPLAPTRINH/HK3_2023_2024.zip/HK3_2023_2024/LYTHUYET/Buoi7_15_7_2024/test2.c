// bài sửa của test.c
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int findDub(char *str);

int main()
{
    char a[100];
    printf("Nhap chuoi: ");
    fgets(a, sizeof(a), stdin);
    
    // Loại bỏ ký tự newline nếu có
    size_t len = strlen(a);
    if (len > 0 && a[len - 1] == '\n') {
        a[len - 1] = '\0';
    }

    int dub = findDub(a);
    printf("Tong so lan cac tu bi lap: %d\n", dub);
    return 0;
}

int findDub(char *str)
{
    char *Words[100];
    int count[100] = {0};
    int wordCount = 0;
    char *token = strtok(str, " ");
    while (token != NULL)
    {
        int found = 0;
        for (int i = 0; i < wordCount; i++)
        {
            if (strcasecmp(token, Words[i]) == 0)
            {
                count[i]++;
                found = 1;
                break;
            }
        }
        if (!found)
        {
            Words[wordCount] = token;
            count[wordCount] = 1;
            wordCount++;
        }
        token = strtok(NULL, " ");
    }
    
    int dub = 0;
    for (int i = 0; i < wordCount; i++) {
        if (count[i] > 1) {
            dub++;
        }
    }
    return dub;
}
