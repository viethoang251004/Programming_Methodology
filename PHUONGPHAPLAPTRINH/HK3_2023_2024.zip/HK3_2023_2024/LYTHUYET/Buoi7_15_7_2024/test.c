// #include <stdio.h>
// #include <string.h>

// int NTB(char wordcount[], int len);

// void main() {
//     char a[100];
//     // int len = strlen(a);
//     printf("Nhap chuoi: ");
//     fgets(a, sizeof(a), stdin);
//     int len = strlen(a);
//     int ntb = NTB(a, len);
//     printf("Số từ trong chuỗi %s là: %d", a, ntb);
//     return 0;
// }
// int NTB(char wordcount[], int len) {
//     int i, ntb = wordcount[0] != ' ';
//     for (i = 0; i < len - 1; i++) {
//         if (wordcount[i] == ' ' && wordcount[i + 1] != ' ') {
//             ntb++;
//         }
//     }
//     return ntb; // +1 cho tinh tu cuoi chuoi
// }

// #include <stdio.h>
// #include <string.h>
// int WordCount(char str[], int length);
// int main()
// {
//     char inputString[100];
//     printf("Nhập chuỗi: ");
//     fgets(inputString, sizeof(inputString), stdin);
//     int length = strlen(inputString);
//     int wordCount = WordCount(inputString, length);
//     printf("Số từ trong chuỗi \"%s\" là %d\n", inputString, wordCount);
//     return 0;
// }
// int WordCount(char str[], int length)
// {
//     int word = (str[0] != ' ');
//     for (int i = 0; i < length - 1; i++)
//     {
//         if (str[i] == ' ' && str[i + 1] != ' ')
//         {
//             word++;
//         }
//     }
//     return word;
// }

// #include <stdio.h>
// #include <string.h>

// int tinhGiaiThua(int n) {
//     int result;
//     if (n == 0) {
//         printf("0\n");
//         return 1;
//     }
//     else {
//         printf("%d", result);
//         return result = n * tinhGiaiThua(n + 1);
//     }
// }
// int main() {
//     int n;
//     printf("Nhap so n: ");
//     scanf("%d", &n);
//     printf("Giai thua cua %d la: %d\n", n, tinhGiaiThua(n));
//     return 0;
// }

// #include <stdio.h>
// #include <string.h>
// #include <ctype.h>

// void trim(char* s) {
//     int start = 0;
//     int end = strlen(s) - 1;
//     while (s[start] == ' '){
//         start++;
//     }
//     while (s[end] == ' '){
//         end--;
//     }
//     for (int i = start; i <= end; i++) {
//         s[i - start] = s[i];
//     }
// }
// void normalize(char* s) {
//     trim(s);
//     int end = strlen(s) - 1;
//     int hasNextAlpha = 1;

//     for (int i = 0; i <= end; i++) {
//         if (s[i] == ' ') {
//             hasNextAlpha = 1;
//         }
//         if (s[i] == ' ' && hasNextAlpha == 1) {
//             continue;
//         }
//         if (hasNextAlpha == 1) {
//             s[i] = toupper(s[i]);
//             hasNextAlpha = 0;
//         }
//         else {
//             s[i] = tolower(s[i]);
//         }
//     }
// }

// int main() {
//     char s[] = "heLLo WorLD, my name is HoANg";
//     normalize(s);
//     printf("New string: ");
//     printf("%s", s);
//     return 0;
// }

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int i, j;
int findDub(char *);
int main()
{
    char a[100];
    int tem;
    int dub;
    printf("Nhap chuoi: ");
    fgets(a, sizeof(a), stdin);
    // int dub;
    // int tem;
    strcpy(tem, a);     // chưa khai báo biến tem
    dub = findDub(tem); // chưa khai báo biến dub hoặc đã khai báo biến dub trong hàm findDub mà để trong vòng lặp while nên hàm main không nhận
    printf("Tong so lan cac chu bi lap: %d", dub);
}

int findDub(char *str)
{
    char *Words[100];
    int count[100] = {0};
    int wordCount = 0;
    char *token = strtok(str, " ");
    while (token != NULL)
    {
        int found = 0;
        for (i = 0; i < wordCount; i++)
        {
            int equal = 1;
            for (j = 0; token[j] && Words[i][j]; i++)
            {
                if (tolower(token[i]) != tolower(Words[i][j]))
                {
                    equal = 0;
                    break;
                }
            }
                if (equal)
                {
                    count[i]++;
                    found = 1;
                    break;
                }
            }
            if (!found)
            {
                Words[wordCount]++;
                count[wordCount]++;
                wordCount++;
            }
            token = strtok(NULL, " ");
        }
        int dub = 0;

        for (i = 0; i < wordCount; i++) {
            if (count[i] > 1) {
                dub++;
            }
        }
        return dub;
    }
    // int dub = 0;

    // for (i = 0; i < wordCount; i++)
    // {
    //     if (count[i] > 1)
    //     {
    //         dub++;
    //     }
    // }
    // return dub;
/*}*/ // thiếu dấu } để đóng hàm findDub
