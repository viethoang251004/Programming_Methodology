// // bài sửa của test1.c
// #include <stdio.h>
// #include <string.h>

// int main() {
//     char a[100];
//     int i, j;
//     printf("Nhap chuoi: ");
//     fgets(a, sizeof(a), stdin);

//     // Loại bỏ ký tự newline nếu có
//     size_t len = strlen(a);
//     if (len > 0 && a[len - 1] == '\n') {
//         a[len - 1] = '\0';
//     }

//     char *ntb = strtok(a, " ");
//     char *words[100];
//     int word_count[100] = {0};
//     int num_words = 0;

//     while (ntb != NULL) {
//         int found = 0;
//         for (i = 0; i < num_words; i++) {
//             if (strcasecmp(ntb, words[i]) == 0) {
//                 word_count[i]++;
//                 found = 1;
//                 break;
//             }
//         }
//         if (!found) {
//             words[num_words] = ntb;
//             word_count[num_words] = 1;
//             num_words++;
//         }
//         ntb = strtok(NULL, " ");
//     }

//     int count = 0;
//     for (i = 0; i < num_words; i++) {
//         if (word_count[i] >= 2) {
//             count++;
//         }
//     }

//     printf("So tu lap lai hon 2 lan: %d\n", count);

//     return 0;
// }

#include <stdio.h> #include <string.h> typedef struct { char name[12]; int  age; char gender; } player_t; Unit19_Demo1.c player1: name = Brusco; age = 23; gender = M player2: name = July; age = 21; gender = F Type definition int main(void) { player_t player1 = { "Brusco", 23, 'M' }, player2; strcpy(player2.name, "July"); player2.age = 21; player2.gender = 'F'; Initialization Accessing members printf("player1: name = %s; age = %d; gender = %c\n", player1.name, player1.age, player1.gender); printf("player2: name = %s; age = %d; gender = %c\n", player2.name, player2.age, player2.gender); return 0; }