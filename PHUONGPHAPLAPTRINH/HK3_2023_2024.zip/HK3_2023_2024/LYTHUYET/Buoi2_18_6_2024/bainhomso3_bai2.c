#include <stdio.h>
#include <math.h>

#define PI 3.14159265

int main() {
    float a, b, angle, area;

    printf("Nhap do dai canh thu nhat: ");
    scanf("%f", &a);
    printf("Nhap do dai canh thu hai: ");
    scanf("%f", &b);
    printf("Nhap goc giua hai canh (tinh bang do): ");
    scanf("%f", &angle);

    // Chuyen doi goc tu do sang radian
    angle = angle * (PI / 180.0);

    // Tinh dien tich hinh binh hanh
    area = a * b * sin(angle);

    printf("Dien tich cua hinh binh hanh la: %.2f\n", area);

    return 0;
}
