#include <stdio.h>

int main() {
    // Khai báo các biến để lưu trữ các hệ số và giá trị x
    double a, b, c, x, result;

    // Nhập các hệ số a, b, c và giá trị x từ bàn phím
    printf("Nhập hệ số a: ");
    scanf("%lf", &a);

    printf("Nhập hệ số b: ");
    scanf("%lf", &b);

    printf("Nhập hệ số c: ");
    scanf("%lf", &c);

    printf("Nhập giá trị x: ");
    scanf("%lf", &x);

    // Tính giá trị của đa thức f(x) = ax^2 + bx + c
    result = a * x * x + b * x + c;

    // In kết quả
    printf("Giá trị của đa thức f(x) = %.2lfx^2 + %.2lfx + %.2lf tại x = %.2lf là: %.2lf\n", a, b, c, x, result);

    return 0;
}
