#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

typedef struct {
    char maSanPham[10];
    char tenSanPham[50];
    int soLuong;
    float gia;
} SanPham;

SanPham dsSanPham[MAX];
int soLuongSanPham = 0;

void themSanPham() {
    if (soLuongSanPham >= MAX) {
        printf("Danh sách sản phẩm đầy!\n");
        return;
    }
    SanPham sp;
    printf("Nhập mã sản phẩm: ");
    scanf("%s", sp.maSanPham);
    printf("Nhập tên sản phẩm: ");
    scanf("%s", sp.tenSanPham);
    printf("Nhập số lượng: ");
    scanf("%d", &sp.soLuong);
    printf("Nhập giá: ");
    scanf("%f", &sp.gia);
    dsSanPham[soLuongSanPham++] = sp;
    printf("Thêm sản phẩm thành công!\n");
}

void xoaSanPham() {
    char maSanPham[10];
    printf("Nhập mã sản phẩm cần xóa: ");
    scanf("%s", maSanPham);
    int found = 0;
    for (int i = 0; i < soLuongSanPham; i++) {
        if (strcmp(dsSanPham[i].maSanPham, maSanPham) == 0) {
            found = 1;
            for (int j = i; j < soLuongSanPham - 1; j++) {
                dsSanPham[j] = dsSanPham[j + 1];
            }
            soLuongSanPham--;
            printf("Xóa sản phẩm thành công!\n");
            break;
        }
    }
    if (!found) {
        printf("Không tìm thấy sản phẩm với mã %s!\n", maSanPham);
    }
}

void timSanPham() {
    char maSanPham[10];
    printf("Nhập mã sản phẩm cần tìm: ");
    scanf("%s", maSanPham);
    for (int i = 0; i < soLuongSanPham; i++) {
        if (strcmp(dsSanPham[i].maSanPham, maSanPham) == 0) {
            printf("Sản phẩm tìm thấy:\n");
            printf("Mã sản phẩm: %s\n", dsSanPham[i].maSanPham);
            printf("Tên sản phẩm: %s\n", dsSanPham[i].tenSanPham);
            printf("Số lượng: %d\n", dsSanPham[i].soLuong);
            printf("Giá: %.2f\n", dsSanPham[i].gia);
            return;
        }
    }
    printf("Không tìm thấy sản phẩm với mã %s!\n", maSanPham);
}

void capNhatSanPham() {
    char maSanPham[10];
    printf("Nhập mã sản phẩm cần cập nhật: ");
    scanf("%s", maSanPham);
    for (int i = 0; i < soLuongSanPham; i++) {
        if (strcmp(dsSanPham[i].maSanPham, maSanPham) == 0) {
            printf("Nhập số lượng mới: ");
            scanf("%d", &dsSanPham[i].soLuong);
            printf("Nhập giá mới: ");
            scanf("%f", &dsSanPham[i].gia);
            printf("Cập nhật sản phẩm thành công!\n");
            return;
        }
    }
    printf("Không tìm thấy sản phẩm với mã %s!\n", maSanPham);
}

void luuDuLieu() {
    FILE *f = fopen("output.txt", "w");
    if (f == NULL) {
        printf("Không thể mở file để ghi dữ liệu!\n");
        return;
    }
    for (int i = 0; i < soLuongSanPham; i++) {
        fprintf(f, "%s %s %d %.2f\n", dsSanPham[i].maSanPham, dsSanPham[i].tenSanPham, dsSanPham[i].soLuong, dsSanPham[i].gia);
    }
    fclose(f);
    printf("Lưu dữ liệu thành công!\n");
}

int main() {
    int choice;
    while (1) {
        printf("1. Thêm sản phẩm\n");
        printf("2. Xóa sản phẩm\n");
        printf("3. Tìm kiếm sản phẩm\n");
        printf("4. Cập nhật sản phẩm\n");
        printf("5. Lưu dữ liệu\n");
        printf("6. Thoát\n");
        printf("Nhập lựa chọn của bạn: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                themSanPham();
                break;
            case 2:
                xoaSanPham();
                break;
            case 3:
                timSanPham();
                break;
            case 4:
                capNhatSanPham();
                break;
            case 5:
                luuDuLieu();
                break;
            case 6:
                luuDuLieu(); // Lưu dữ liệu trước khi thoát
                exit(0);
            default:
                printf("Lựa chọn không hợp lệ!\n");
        }
    }
    return 0;
}
