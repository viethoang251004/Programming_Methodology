#include <stdio.h>

// Khai báo hàm con
void sumEvenOdd(int *array, int size, int *sumEven, int *sumOdd);

int main() {
    int array[] = {1, 2, 3, 4, 5};
    int size = sizeof(array) / sizeof(array[0]);
    int sumEven, sumOdd;

    // Gọi hàm con để tính tổng các số chẵn và tổng các số lẻ
    sumEvenOdd(array, size, &sumEven, &sumOdd);

    // In kết quả tổng các số chẵn và tổng các số lẻ
    printf("Sum of even numbers: %d\n", sumEven);
    printf("Sum of odd numbers: %d\n", sumOdd);

    return 0;
}

// Định nghĩa hàm con
void sumEvenOdd(int *array, int size, int *sumEven, int *sumOdd) {
    *sumEven = 0;
    *sumOdd = 0;
    for (int i = 0; i < size; i++) {
        if (array[i] % 2 == 0) {
            *sumEven += array[i];  // Cộng số chẵn vào tổng số chẵn
        } else {
            *sumOdd += array[i];   // Cộng số lẻ vào tổng số lẻ
        }
    }
}


void inputNumber() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);
    printf("Number entered: %d\n", number);
}

void outputNumber() {
    
}