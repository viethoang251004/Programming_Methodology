#include <stdio.h>
#include <stdlib.h>

// Khai báo hàm con
void splitArray(int *array, int size, int splitValue, int **lowerArray, int *lowerSize, int **higherArray, int *higherSize);

int main() {
    int array[] = {3, 7, 2, 8, 5, 1, 6, 4};
    int size = sizeof(array) / sizeof(array[0]);
    int splitValue = 4; // Giá trị để tách mảng

    int *lowerArray, *higherArray;
    int lowerSize, higherSize;

    // Gọi hàm con để tách mảng thành hai mảng con
    splitArray(array, size, splitValue, &lowerArray, &lowerSize, &higherArray, &higherSize);

    // In các phần tử của mảng con thấp hơn hoặc bằng splitValue
    printf("Lower array: ");
    for (int i = 0; i < lowerSize; i++) {
        printf("%d ", lowerArray[i]);
    }
    printf("\n");

    // In các phần tử của mảng con cao hơn splitValue
    printf("Higher array: ");
    for (int i = 0; i < higherSize; i++) {
        printf("%d ", higherArray[i]);
    }
    printf("\n");

    // Giải phóng bộ nhớ đã cấp phát cho mảng con
    free(lowerArray);
    free(higherArray);

    return 0;
}

// Định nghĩa hàm con
void splitArray(int *array, int size, int splitValue, int **lowerArray, int *lowerSize, int **higherArray, int *higherSize) {
    // Khởi tạo kích thước ban đầu của mảng con
    *lowerSize = 0;
    *higherSize = 0;

    // Đếm số lượng phần tử nhỏ hơn hoặc bằng splitValue
    for (int i = 0; i < size; i++) {
        if (array[i] <= splitValue) {
            (*lowerSize)++;
        } else {
            (*higherSize)++;
        }
    }

    // Cấp phát bộ nhớ cho mảng con thấp hơn splitValue và cao hơn splitValue
    *lowerArray = (int *)malloc(*lowerSize * sizeof(int));
    *higherArray = (int *)malloc(*higherSize * sizeof(int));

    if (*lowerArray == NULL || *higherArray == NULL) {
        printf("Memory allocation failed.\n");
        return;
    }

    // Sao chép các phần tử vào mảng con thấp hơn splitValue và cao hơn splitValue
    int lowerIndex = 0;
    int higherIndex = 0;
    for (int i = 0; i < size; i++) {
        if (array[i] <= splitValue) {
            (*lowerArray)[lowerIndex++] = array[i];
        } else {
            (*higherArray)[higherIndex++] = array[i];
        }
    }
}
