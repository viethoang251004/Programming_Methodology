#include <stdio.h>

// Khai báo hàm con
void calculateAverageAndCount(int *array, int size, double *average, int *count);

int main() {
    int array[] = {1, 2, 3, 4, 5};
    int size = sizeof(array) / sizeof(array[0]);
    double average;
    int count;

    // Gọi hàm con để tính giá trị trung bình và đếm số phần tử lớn hơn giá trị trung bình
    calculateAverageAndCount(array, size, &average, &count);

    // In giá trị trung bình và số lượng phần tử lớn hơn giá trị trung bình
    printf("Average: %.2f\n", average);
    printf("Count greater than average: %d\n", count);

    return 0;
}

// Định nghĩa hàm con
void calculateAverageAndCount(int *array, int size, double *average, int *count) {
    int sum = 0;
    *count = 0;
    for (int i = 0; i < size; i++) {
        sum += array[i];  // Tính tổng các phần tử
    }
    *average = (double)sum / size;  // Tính giá trị trung bình
    for (int i = 0; i < size; i++) {
        if (array[i] > *average) {
            (*count)++;  // Đếm số phần tử lớn hơn giá trị trung bình
        }
    }
}
