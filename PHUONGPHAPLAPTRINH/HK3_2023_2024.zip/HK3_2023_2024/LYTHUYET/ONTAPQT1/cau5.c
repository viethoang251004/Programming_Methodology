#include <stdio.h>
#include <stdlib.h>

// Khai báo hàm con
int *findCommonElements(int *array1, int size1, int *array2, int size2, int *commonCount);

int main() {
    int array1[] = {1, 2, 3, 4, 5};
    int size1 = sizeof(array1) / sizeof(array1[0]);

    int array2[] = {3, 4, 5, 6, 7};
    int size2 = sizeof(array2) / sizeof(array2[0]);

    int commonCount;
    int *commonElements = findCommonElements(array1, size1, array2, size2, &commonCount);

    if (commonElements == NULL) {
        return 1; // Xử lý lỗi nếu cấp phát bộ nhớ thất bại
    }

    // In ra các phần tử nguyên chung
    printf("Common elements: ");
    for (int i = 0; i < commonCount; i++) {
        printf("%d ", commonElements[i]);
    }
    printf("\n");

    // Giải phóng bộ nhớ đã cấp phát cho mảng commonElements
    free(commonElements);

    return 0;
}

// Định nghĩa hàm con
int *findCommonElements(int *array1, int size1, int *array2, int size2, int *commonCount) {
    // Khởi tạo một mảng để lưu các phần tử nguyên chung
    int *commonElements = (int *)malloc(size1 * sizeof(int));
    if (commonElements == NULL) {
        printf("Memory allocation failed.\n");
        return NULL;
    }

    *commonCount = 0;

    // Duyệt qua từng phần tử của mảng 1
    for (int i = 0; i < size1; i++) {
        // Kiểm tra xem phần tử của mảng 1 có trong mảng 2 hay không
        int found = 0;
        for (int j = 0; j < size2; j++) {
            if (array1[i] == array2[j]) {
                found = 1;
                break;
            }
        }
        // Nếu tìm thấy phần tử trong cả hai mảng và chưa được lưu vào mảng commonElements
        if (found) {
            // Kiểm tra xem phần tử đã được lưu trước đó chưa
            int duplicate = 0;
            for (int k = 0; k < *commonCount; k++) {
                if (array1[i] == commonElements[k]) {
                    duplicate = 1;
                    break;
                }
            }
            // Nếu chưa được lưu trước đó, thêm vào mảng commonElements
            if (!duplicate) {
                commonElements[*commonCount] = array1[i];
                (*commonCount)++;
            }
        }
    }

    return commonElements;
}


// #include<stdio.h>

// int main(){
// 	// khởi tạo
// 	int a[5]={4,7,10,6,4};
// 	int b[5]={4,6,9,8,4};
// 	int ab[5] = {0};
// 	int i,j,k,l,count1,count2,count3;
// 	l=count1=count2=count3=0;
	
// 	//duyệt mảng a
// 	for(i=0;i<5;i++){
// 		count1++;
// 		//duyệt mảng b
// 		for(j=0;j<5;j++){
// 			count2++;
// 			/*so sánh giá trị phần tử thứ i của mảng a với từng giá trị phần tử thứ j trong mảng b*/
// 			if(a[i]==b[j]){
// 				/*trước khi chép giá trị trùng vào mảng ab, sẽ kiểm tra xem giá trị này đã có trong mảng ab chưa*/
// 				for(k=0;k<l;k++){
// 					count3++;
// 					/*nếu gia trị trùng đã có trong mảng ab rồi thì dừng vòng lặp*/
// 					if(a[i]==ab[k])
// 						break;
// 				}
// 				/*trường hợp duyệt hết mảng ab thì chép giá trị trùng vào mảng ab*/
// 				if(k==l){
// 					//l sẽ tăng lên mỗi lần chép
// 					ab[l++]=a[i];
// 					break;
// 				}
// 			}
// 		}
// 	}
	
// 	//in ra số lần lặp
// 	printf("count1=%d\n",count1);
// 	printf("count2=%d\n",count2);
// 	printf("count3=%d\n",count3);
	
// 	printf("l=%d\n",l);
	
// 	//xuất giá trị mảng ab
// 	for(i=0;i<l;i++)
// 		printf("ab[%d]:%d\n",i,ab[i]);
	
// 	return 0;
// }