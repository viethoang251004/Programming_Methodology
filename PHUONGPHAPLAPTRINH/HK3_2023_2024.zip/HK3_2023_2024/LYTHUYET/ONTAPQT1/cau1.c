#include <stdio.h>
#include <stdlib.h>

// Khai báo hàm con
void copyArray(int *source, int *destination, int size);

int main() {
    int sourceArray[] = {1, 2, 3, 4, 5};
    int size = sizeof(sourceArray) / sizeof(sourceArray[0]);

    // Cấp phát bộ nhớ cho mảng đích có cùng kích thước với mảng nguồn
    int *destinationArray = (int *)malloc(size * sizeof(int));
    if (destinationArray == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Gọi hàm con để sao chép mảng nguồn vào mảng đích
    copyArray(sourceArray, destinationArray, size);

    // In ra mảng đích sau khi sao chép
    printf("Source Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", sourceArray[i]);
    }
    printf("\n");

    printf("Destination Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", destinationArray[i]);
    }
    printf("\n");

    // Giải phóng bộ nhớ đã cấp phát cho mảng đích
    free(destinationArray);

    return 0;
}

// Định nghĩa hàm con
void copyArray(int *source, int *destination, int size) {
    // Duyệt qua từng phần tử của mảng nguồn và sao chép vào mảng đích
    for (int i = 0; i < size; i++) {
        *(destination + i) = *(source + i);
    }
}
