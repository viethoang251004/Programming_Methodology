#include <stdio.h>

// Khai báo hàm con
int isSymmetric(int *array, int size);

int main() {
    int array1[] = {1, 2, 3, 2, 1};
    int size1 = sizeof(array1) / sizeof(array1[0]);

    int array2[] = {1, 2, 3, 4, 5};
    int size2 = sizeof(array2) / sizeof(array2[0]);

    // Kiểm tra tính đối xứng của mảng 1
    if (isSymmetric(array1, size1)) {
        printf("Array 1 is symmetric.\n");
    } else {
        printf("Array 1 is not symmetric.\n");
    }

    // Kiểm tra tính đối xứng của mảng 2
    if (isSymmetric(array2, size2)) {
        printf("Array 2 is symmetric.\n");
    } else {
        printf("Array 2 is not symmetric.\n");
    }

    return 0;
}

// Định nghĩa hàm con
int isSymmetric(int *array, int size) {
    // Khai báo biến chỉ số và biến đối xứng
    int left = 0;
    int right = size - 1;

    // Kiểm tra tính đối xứng
    while (left < right) {
        if (array[left] != array[right]) {
            return 0; // Không đối xứng
        }
        left++;
        right--;
    }
    return 1; // Đối xứng
}
