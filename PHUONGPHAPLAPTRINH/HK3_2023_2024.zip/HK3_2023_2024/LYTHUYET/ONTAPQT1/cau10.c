#include <stdio.h>

// Khai báo hàm con
int countUniqueElements(int *array1, int size1, int *array2, int size2);

int main() {
    int array1[] = {1, 2, 3, 4, 5};
    int size1 = sizeof(array1) / sizeof(array1[0]);

    int array2[] = {3, 4, 5, 6, 7};
    int size2 = sizeof(array2) / sizeof(array2[0]);

    // Gọi hàm con để đếm số lượng phần tử không trùng nhau
    int count = countUniqueElements(array1, size1, array2, size2);

    printf("Number of unique elements: %d\n", count);

    return 0;
}

// Định nghĩa hàm con
int countUniqueElements(int *array1, int size1, int *array2, int size2) {
    int uniqueCount = 0;
    int found;

    // Duyệt qua từng phần tử của mảng 1
    for (int i = 0; i < size1; i++) {
        found = 0; // Đánh dấu có tìm thấy phần tử không trùng nhau
        // Kiểm tra xem phần tử của mảng 1 có trùng trong mảng 2 hay không
        for (int j = 0; j < size2; j++) {
            if (array1[i] == array2[j]) {
                found = 1;
                break;
            }
        }
        // Nếu không tìm thấy phần tử này trong mảng 2, đếm vào số phần tử không trùng nhau
        if (!found) {
            uniqueCount++;
        }
    }

    // Duyệt qua từng phần tử của mảng 2 để kiểm tra những phần tử không trùng nhau với mảng 1
    for (int i = 0; i < size2; i++) {
        found = 0; // Đánh dấu có tìm thấy phần tử không trùng nhau
        // Kiểm tra xem phần tử của mảng 2 có trùng trong mảng 1 hay không
        for (int j = 0; j < size1; j++) {
            if (array2[i] == array1[j]) {
                found = 1;
                break;
            }
        }
        // Nếu không tìm thấy phần tử này trong mảng 1, đếm vào số phần tử không trùng nhau
        if (!found) {
            uniqueCount++;
        }
    }

    return uniqueCount;
}
