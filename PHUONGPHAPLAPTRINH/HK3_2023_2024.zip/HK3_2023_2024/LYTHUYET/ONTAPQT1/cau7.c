#include <stdio.h>

// Khai báo hàm con
void insertElement(int *array, int *size, int position, int element);

int main() {
    int array[10] = {1, 2, 3, 4, 5};
    int size = 5;  // Kích thước ban đầu của mảng
    int position = 2;  // Vị trí muốn chèn phần tử (tính từ 0)
    int element = 10;  // Phần tử muốn chèn vào mảng

    // Gọi hàm con để chèn phần tử vào mảng
    insertElement(array, &size, position, element);

    // In mảng sau khi đã chèn phần tử
    printf("Array after insertion: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

// Định nghĩa hàm con
void insertElement(int *array, int *size, int position, int element) {
    // Kiểm tra điều kiện vị trí hợp lệ
    if (position < 0 || position > *size) {
        printf("Invalid position!\n");
        return;
    }

    // Dịch chuyển các phần tử sang phải để tạo không gian cho phần tử mới
    for (int i = *size - 1; i >= position; i--) {
        array[i + 1] = array[i];
    }

    // Chèn phần tử vào vị trí đã cho
    array[position] = element;

    // Tăng kích thước mảng
    (*size)++;
}
