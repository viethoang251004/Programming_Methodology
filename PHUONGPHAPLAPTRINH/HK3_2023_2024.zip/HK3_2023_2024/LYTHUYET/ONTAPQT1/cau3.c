#include <stdio.h>

// Khai báo hàm con
void sortArray(int *array, int size, int ascending);

int main() {
    int array[] = {5, 3, 8, 6, 2};
    int size = sizeof(array) / sizeof(array[0]);

    // Sắp xếp mảng theo thứ tự tăng dần
    sortArray(array, size, 1);
    printf("Array in ascending order: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    // Sắp xếp mảng theo thứ tự giảm dần
    sortArray(array, size, 0);
    printf("Array in descending order: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}

// Định nghĩa hàm con
void sortArray(int *array, int size, int ascending) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = i + 1; j < size; j++) {
            if ((ascending && array[i] > array[j]) || (!ascending && array[i] < array[j])) {
                // Hoán đổi các phần tử
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}
