#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int scanFile(float a[]);

int main(){
	float a[100];
	int size =0;
	size=scanFile(a);
	
	printf("size=%d\n",size);
	for(int i=0;i<size;i++)
		printf("a[%d]:%0.2f\t",i,a[i]);
	return 0;
}

int scanFile(float a[]) {
	FILE *f;
	int i, size, c;
	i=size=0;
	
	f=fopen("input.txt","r");
	if(f==NULL){
		printf("file không tồn tại");
		exit(1);
	}
	fscanf(f,"%d",&size);
	
	while(fscanf(f,"%c",&c)!=EOF){
		if(isdigit(c)){
			ungetc(c,f);
			fscanf(f,"%f",&a[i++]);
		}
	}
	fclose(f);
	return size;
}