#include <stdio.h>

// Hàm để nhập mảng
void nhapMang(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("Nhập phần tử thứ %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
}

// Hàm để xuất mảng
void xuatMang(int arr[], int n) {
    printf("Các phần tử của mảng là: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Chương trình chính
int main() {
    int n;

    // Nhập số lượng phần tử của mảng
    printf("Nhập số lượng phần tử của mảng: ");
    scanf("%d", &n);

    // Khai báo mảng
    int arr[n];

    // Gọi hàm nhập mảng
    nhapMang(arr, n);

    // Gọi hàm xuất mảng
    xuatMang(arr, n);

    return 0;
}
