#include <stdio.h>
#include <limits.h>

// Hàm con để tính tổng các chữ số, tổng các chữ số chẵn, và chữ số nhỏ nhất
void calculateDigits(int a, int *sumDigits, int *sumEvenDigits, int *minDigit) {
    // *sumDigits = 0;
    // *sumEvenDigits = 0;
    // *minDigit = INT_MAX;

    if (a < 0) {
        printf("Vui lòng nhập số nguyên dương.");
    }
    if (a > 0) {
    // Xử lý từng chữ số
        *sumDigits = 0;
        *sumEvenDigits = 0;
        *minDigit = INT_MAX;
        while (a > 0) {
            // *sumDigits = 0;
            // *sumEvenDigits = 0;
            // *minDigit = INT_MAX;
            int digit = a % 10;
            *sumDigits += digit;
            if (digit % 2 == 0) {
                *sumEvenDigits += digit;
            }
            if (digit < *minDigit) {
                *minDigit = digit;
            }
            a /= 10;
        }
    }
    if (a == 0) {
        *sumDigits = 0;
        *sumEvenDigits = 0;
        *minDigit = 0;
    }
}

// Chương trình chính
int main() {
    int n;
    int sumDigits, sumEvenDigits, minDigit;

    printf("Nhập một số nguyên dương: ");
    scanf("%d", &n);

    if (n < 0) {
        // Gọi hàm con để tính toán
        calculateDigits(n, &sumDigits, &sumEvenDigits, &minDigit);
    }
    if (n > 0) {
        calculateDigits(n, &sumDigits, &sumEvenDigits, &minDigit);
        printf("Tổng các chữ số: %d\n", sumDigits);
        printf("Tổng các chữ số chẵn: %d\n", sumEvenDigits);
        printf("Chữ số nhỏ nhất: %d\n", minDigit);        
    }
    if (n == 0) {
        calculateDigits(n, &sumDigits, &sumEvenDigits, &minDigit);
        printf("Tổng các chữ số: %d\n", sumDigits);
        printf("Tổng các chữ số chẵn: %d\n", sumEvenDigits);
        printf("Chữ số nhỏ nhất: %d\n", minDigit);
    }
    // printf("Tổng các chữ số: %d\n", sumDigits);
    // printf("Tổng các chữ số chẵn: %d\n", sumEvenDigits);
    // printf("Chữ số nhỏ nhất: %d\n", minDigit);

    return n, sumDigits, sumEvenDigits, minDigit;
}
