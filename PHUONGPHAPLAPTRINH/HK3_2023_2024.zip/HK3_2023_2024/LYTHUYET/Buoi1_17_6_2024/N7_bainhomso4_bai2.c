#include <stdio.h>
#include <math.h>

void checkTheLargestNumber(int a, int b){
    if (a > b) {
        printf("%d is the largest number.\n", a);
    }
    if (a < b) {
        printf("%d is the largest number.\n", b);
    }
    if (a == b) {
        printf("%d is the largest number.\n", a);
    }
}

int main() {
    int a, b;
    printf("Enter the first number: ");
    scanf("%d", &a);
    printf("Enter the second number: ");
    scanf("%d", &b);
    checkTheLargestNumber(a,b);
    return 0;
}