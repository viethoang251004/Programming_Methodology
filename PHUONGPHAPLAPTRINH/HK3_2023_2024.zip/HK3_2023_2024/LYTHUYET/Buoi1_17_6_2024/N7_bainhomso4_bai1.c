#include <stdio.h>

int isEven(int number) {
    if (number % 2==0) {
        return 1;
    }
    else {
        // return 0;
    }
}

int main() {
    int number;
    printf("Nhập số n: ");
    scanf("%d", &number);
    if (isEven(number)){
        printf("%d là số chẵn.\n", number);
    }
    else {
        printf("%d là số lẻ.\n", number);
    }
}