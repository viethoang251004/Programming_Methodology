#include <stdio.h>
// int main(void) {
//     double a, *b;
//     b = &a;
//     *b = 12.34;
//     printf("%.2f\n", &a);
//     return 0;
// }

void main() {
    int i = 10, j = 20;
    printf("Dia chi bien i: %d\n", &i);
    printf("Dia chi bien j: %d\n", &j);

    int *p = &i;
    printf("gia tri cua p:%d\n", p);
    printf("gia tri cua con tro p tro toi: %d\n", *p);
    printf("dia chi cua bien p:%d\n", &p);
    *p = *p  + 2;
    p = &j;
    *p = i;
    printf("gia tri cua i: %d\n", i);
    printf("gia tri cua j: %d\n", j);
}