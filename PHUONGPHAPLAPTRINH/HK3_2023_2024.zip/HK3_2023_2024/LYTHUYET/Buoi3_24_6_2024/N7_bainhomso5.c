#include <stdio.h>
#include <math.h>

// Hàm kiểm tra số chính phương
int soChinhPhuong(int num) {
    int sqrtNum = sqrt(num);
    return sqrtNum * sqrtNum == num;
}

// Hàm nhập vào một số nguyên dương n
int nhapInputLaSoNguyenDuong() {
    int n;
    do{
        printf("Nhập một số nguyên dương n: ");
        scanf("%d", &n);
        if (n <= 0) {
            printf("Vui lòng nhập một số nguyên dương.\n");
        }
    }while(n<=0);
    return n;
}

// Hàm xuất ra màn hình là các số chính phương
void inSoChinhPhuong(int n){
    printf("Các số chính phương từ 1 đến %d: \n",n);
    for (int i = 1; i <= n; i++) {
        if (soChinhPhuong(i)) {
            printf("%d, ", i);
        }
    }
    printf("\n");
}

// Hàm tính tổng các số chính phương từ 1 đến n
int tongCacSoChinhPhuong(int n) {
    int sum = 0;
    int i = 1;
    while (i <= n) {
        if (soChinhPhuong(i)) {
            sum += i;
        }
        i++;
    }
    return sum;
}

// Hàm tính tổng các số chẵn là số chính phương từ 1 đến n
int tongCacSoChanLaSoChinhPhuong(int n) {
    int sum = 0;
    int i;
    for (i = 1; i <= n; i++) {
        if (soChinhPhuong(i) && i % 2 == 0) {
            sum = sum + i;
        }
    }
    return sum;
}

int main() {
    int n = nhapInputLaSoNguyenDuong();
    inSoChinhPhuong(n);
    int tongSoChinhPhuong;
    tongSoChinhPhuong = tongCacSoChinhPhuong(n);
    printf("Tổng các số chính phương từ 1 đến %d: %d\n",n, tongSoChinhPhuong);
    int tongSoChanLaSoChinhPhuong;
    tongSoChanLaSoChinhPhuong = tongCacSoChanLaSoChinhPhuong(n);
    printf("Tổng các số chẵn là số chính phương từ 1 đến %d: %d\n",n, tongSoChanLaSoChinhPhuong);
}

// #include <stdio.h>
// #include <math.h>

// // Hàm dùng để nhập n từ bàn phím
// int inputNumber(){
//     int n;
//     printf("Nhập n: ");
//     scanf("%d", &n);

// }