#include <stdio.h>

void swap(int *x, int *y) {
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

int main(/*int argc, char *argv[]*/)
{
    int a, b;
    printf("Nhập số nguyên a: ");
    scanf("%d", &a);
    printf("Nhập số nguyên b: ");
    scanf("%d", &b);
    // In giá trị của a và b trước khi hoán đổi
    printf("Trước khi hoán đổi: a = %d, b = %d\n", a, b);
    // Gọi hàm hoán đổi
    swap(&a, &b);
    // In giá trị của a và b sau khi hoán đổi
    printf("Sau khi hoán đổi: a = %d, b = %d\n", a, b);
    return 0;
}