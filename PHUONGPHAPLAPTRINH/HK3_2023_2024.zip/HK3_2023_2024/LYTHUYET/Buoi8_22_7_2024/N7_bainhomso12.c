#include <stdio.h>
#include <stdlib.h>
typedef struct {
    char name[50];
    double salary;
    int age;
} Employee;
double totalSalaryAboveAge(Employee employees[], int count, int age) {
    double total = 0.0;
    for(int i = 0; i < count; i++) {
        if(employees[i].age > age) {
            total += employees[i].salary;
        }
    }
    return total;
}
void inputEmployees(Employee employees[], int count) {
    for(int i = 0; i < count; i++) {
        printf("Enter details for employee %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", employees[i].name);
        printf("Salary: ");
        scanf("%lf", &employees[i].salary);
        printf("Age: ");
        scanf("%d", &employees[i].age);
    }
}
double averageSalary(Employee employees[], int count) {
    double total = 0.0;
    for(int i = 0; i < count; i++) {
        total += employees[i].salary;
    }
    return total / count;
}
int main() {
    int n, age;   
    printf("Enter the number of employees: ");
    scanf("%d", &n);
    Employee *employees = (Employee *)malloc(n * sizeof(Employee));
    inputEmployees(employees, n);
    printf("Enter the age to filter employees: ");
    scanf("%d", &age);
    double totalSalary = totalSalaryAboveAge(employees, n, age);
    printf("Total salary of employees older than %d: %.2f\n", age, totalSalary);
    double avgSalary = averageSalary(employees, n);
    printf("Average salary of employees: %.2f\n", avgSalary);
    free(employees);
    return 0;
}
