
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Định nghĩa cấu trúc Employee
typedef struct {
    char name[100];  // Bao gồm họ và tên
    double salary;
    int age;
} Employee;

// Hàm tính tổng lương của các nhân viên có tuổi lớn hơn giá trị x
double totalSalaryAboveAge(Employee employees[], int count, int age) {
    double total = 0.0;
    for (int i = 0; i < count; i++) {
        if (employees[i].age > age) {
            total += employees[i].salary;
        }
    }
    return total;
}

// Hàm tạo danh sách các nhân viên từ dữ liệu nhập từ bàn phím và tính lương trung bình
int inputEmployeesAndCalculateAverage(Employee **employees) {
    int count = 0;
    int capacity = 2;  // Bắt đầu với sức chứa 2 và sẽ tăng gấp đôi khi cần thiết
    double totalSalary = 0.0;
    *employees = (Employee *)malloc(capacity * sizeof(Employee));
    
    while (1) {
        char name[100];
        double salary;
        int age;
        char choice;

        printf("Enter details for employee %d:\n", count + 1);
        printf("Name (or 'done' to finish): ");
        scanf(" %[^\n]", name);

        if (strcmp(name, "done") == 0) {
            break;
        }

        printf("Salary: ");
        scanf("%lf", &salary);
        printf("Age: ");
        scanf("%d", &age);

        if (count == capacity) {
            capacity *= 2;
            *employees = (Employee *)realloc(*employees, capacity * sizeof(Employee));
        }

        strcpy((*employees)[count].name, name);
        (*employees)[count].salary = salary;
        (*employees)[count].age = age;
        totalSalary += salary;
        count++;
    }

    if (count > 0) {
        double averageSalary = totalSalary / count;
        printf("Average salary of employees: %.2f\n", averageSalary);
    }

    return count;
}

int main() {
    Employee *employees;
    int employeeCount = inputEmployeesAndCalculateAverage(&employees);

    if (employeeCount > 0) {
        int age;
        printf("Enter the age to filter employees: ");
        scanf("%d", &age);

        double totalSalary = totalSalaryAboveAge(employees, employeeCount, age);
        printf("Total salary of employees older than %d: %.2f\n", age, totalSalary);

        free(employees);
    } else {
        printf("No employees were entered.\n");
    }

    return 0;
}
