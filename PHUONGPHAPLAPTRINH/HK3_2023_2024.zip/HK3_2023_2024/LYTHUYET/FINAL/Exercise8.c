#include <stdio.h>
main()
{
    char *p = "I love my teacher";
    p[0] = 'a';
    p[1] = 'b';
    printf("%s", p);
}