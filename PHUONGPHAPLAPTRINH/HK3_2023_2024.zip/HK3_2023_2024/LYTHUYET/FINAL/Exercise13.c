#include <stdio.h>
main()
{
    if (sizeof(int) > -1)
        printf("True");
    else
        printf("False");
}