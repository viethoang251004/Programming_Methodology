#include <stdio.h>
// void func(char* ontap)
// {
//     char ontap = "Ta la sieu nhan";
//     printf("%10s",ontap);
//     // return 0;
// }
void main() {
    char ontap = "talasieunhangao";
    printf("%10s",ontap);
    // return 0;
}