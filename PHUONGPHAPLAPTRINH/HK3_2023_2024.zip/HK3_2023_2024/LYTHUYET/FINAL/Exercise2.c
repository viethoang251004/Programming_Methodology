#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *p = 0;
    *p = (char *)malloc(sizeof(char));
    *p = 'a';
    printf("value in pointer p is %c\n", *p);
}
