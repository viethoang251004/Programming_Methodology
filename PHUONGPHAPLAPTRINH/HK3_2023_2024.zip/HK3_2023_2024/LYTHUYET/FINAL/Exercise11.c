#include <stdio.h>
main()
{
    int n = 0, m = 0;
    if (n > 0)
        if (m > 0)
            printf("True");
        else
            printf("False");
}