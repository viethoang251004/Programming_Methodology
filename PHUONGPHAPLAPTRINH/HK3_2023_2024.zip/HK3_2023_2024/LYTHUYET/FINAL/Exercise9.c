#include <stdio.h>
void main()
{
    float x;
    int y;
    printf("enter two numbers \n");
    scanf("%f %d", &x, &y);
    printf("%f, %d", x, y);
}