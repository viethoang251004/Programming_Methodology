#include <stdio.h>
main()
{
    int main = 3;
    printf("%d", main);
    return 0;
}