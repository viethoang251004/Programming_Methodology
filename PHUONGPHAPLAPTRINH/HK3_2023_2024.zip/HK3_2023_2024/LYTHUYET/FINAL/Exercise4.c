#include <stdio.h>

int main()
{
    signed char chr;
    chr = 128;
    printf("%d\n", chr);
    return 0;
}