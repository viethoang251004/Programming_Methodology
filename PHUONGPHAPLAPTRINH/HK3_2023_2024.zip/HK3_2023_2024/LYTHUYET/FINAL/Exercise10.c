#include <stdio.h>
int main()
{
    float f = 0.1;
    if (f == 0.1)
        printf("True");
    else
        printf("False");
}