// #include <stdio.h>
// union Sti
// {
//     int nu;
//     char m;
// };
// int main()
// {
//     union Sti s;
//     int matrix2[2][3] = {{1, 2, 3}, {4, 5, 6}};
//     char names[3][20] = {"Alice","Bob","Charlieabclsdjesdfas"};
//     printf("%d", sizeof(s));
//     return 0;
// }

#include <stdio.h>

int main() {
    double x = 123.456789;
    printf("%.3lf\n", x);
    return 0;
}