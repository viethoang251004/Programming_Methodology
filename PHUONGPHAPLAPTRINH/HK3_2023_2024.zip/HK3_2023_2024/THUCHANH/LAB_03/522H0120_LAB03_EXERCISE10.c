#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int reverseOrderNumber(int num, int reversed);

int main() {
    int num, reversed = 0;
    printf("Enter any positive integer number: ");
    scanf("%d", &num);
    // while (num != 0) {
    //     int digit = num % 10;
    //     reversed = reversed * 10 + digit;
    //     num /= 10;
    // }
    printf("Reversed number: %d\n", reverseOrderNumber(num, reversed));
    return 0;
}

int reverseOrderNumber(int num, int reversed) {
    while (num != 0) {
        int digit = num % 10;
        reversed = reversed * 10 + digit;
        num /= 10;
    }
    return reversed;
}