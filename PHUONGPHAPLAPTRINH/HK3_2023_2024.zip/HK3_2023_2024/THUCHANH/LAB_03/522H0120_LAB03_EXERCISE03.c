#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

void inBangCuuChuong(int number) {
    int i;
    printf("Bảng cửu chương của %d:\n", number);
    for (i = 1; i <= 10; ++i) {
        printf("%d x %d = %d\n", number, i, number * i);
    }
}

int main() {
    int number;
    printf("Nhập vào một số bất kỳ: ");
    scanf("%d", &number);
    inBangCuuChuong(number);
    return 0;
}
