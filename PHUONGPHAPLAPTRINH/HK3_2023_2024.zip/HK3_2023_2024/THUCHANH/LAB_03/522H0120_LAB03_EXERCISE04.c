#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int nhanGiaTriDauVaoHopLe();
int tinhTongCacSoTuNhien(int n);
// int tinhTongBangVongLapWhile(int n);
// int tinhTongBangVongLapDoWhile(int n);

int main() {
    int n = nhanGiaTriDauVaoHopLe();
    printf("Tổng các số tự nhiên giữa từ 1 đến n: %d\n", tinhTongCacSoTuNhien(n));
    // printf("Tổng các số tự nhiên giữa từ 1 đến n sử dụng vòng lặp while: %d\n", tinhTongBangVongLapWhile(n));
    // printf("Tổng các số tự nhiên giữa từ 1 đến n sử dụng vòng lặp do-while: %d\n", tinhTongBangVongLapDoWhile(n));
    return 0;
}
int nhanGiaTriDauVaoHopLe() {
    int n;
    do {
        printf("Nhập một số nguyên dương bất kỳ: ");
        if (scanf("%d", &n) != 1) {
            while(getchar() != '\n'); // getchar() dùng để xóa bộ đệm đầu vào
            n = -1; // Gán n giá trị ko hợp lệ
        }
    } while (n <= 0);
    return n;
}

int tinhTongCacSoTuNhien(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}

// int tinhTongBangVongLapWhile(int n) {
//     int sum = 0;
//     int i = 1;
//     while (i <= n) {
//         sum += i;
//         i++;
//     }
//     return sum;
// }

// int tinhTongBangVongLapDoWhile(int n) {
//     int sum = 0;
//     int i = 1;
//     if (n >= 1) {
//         do {
//             sum += i;
//             i++;
//         } while(i <= n);
//     }
//     return sum;
// }