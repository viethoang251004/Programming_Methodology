#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int sumOfDigits(int number) {
    int sum = 0;
    while (number != 0) {
        sum += number % 10;  // Add the last digit to sum
        number /= 10;        // Remove the last digit
    }
    return sum;
}

int main() {
    int number;
    printf("Nhập vào một số bất kỳ: ");
    scanf("%d", &number);
    int result = sumOfDigits(number);
    printf("Tổng các chữ số của số được nhập vào: %d\n", result);
    return 0;
}
