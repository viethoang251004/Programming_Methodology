#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

void findFirstAndLastDigits(int number, int *first, int *last) {
    *last = number % 10;  // Get the last digit
    // Find the first digit
    while (number >= 10) {
        number /= 10;
    }
    *first = number;  // The remaining number is the first digit
}

int main() {
    int number, firstDigit, lastDigit;
    printf("Nhập vào một số bất kỳ: ");
    scanf("%d", &number);
    findFirstAndLastDigits(number, &firstDigit, &lastDigit);
    printf("Ký tự đầu tiên của số được nhập vào: %d\n", firstDigit);
    printf("Ký tự cuối cùng của số được nhập vào: %d\n", lastDigit);
    return 0;
}
