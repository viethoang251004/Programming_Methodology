#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int countNumberOfDigits(int num, int count);

int main() {
    int num, count = 0;
    printf("Enter any positive integer number: ");
    scanf("%d", &num);

    // if (num < 0) {
    //     num = -num;
    // }

    // if (num == 0) {
    //     count = 1;
    // } else {
    //     // Count the number of digits
    //     while (num != 0) {
    //         num /= 10;
    //         count++;
    //     }
    // }

    printf("Number of digits: %d\n", countNumberOfDigits(num, count));
    return num;
}

int countNumberOfDigits(int num, int count) {
    if (num < 0) {
        num = -num;
    }
    if (num == 0) {
        count = 1;
    } else {
        // Count the number of digits
        while (num != 0) {
            num /= 10;
            count++;
        }
    }
    return count;
}