#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int isPalindrome(int num) {
    int reversed = 0, original = num, remainder;
    // Reverse the number
    while (num != 0) {
        remainder = num % 10;
        reversed = reversed * 10 + remainder;
        num /= 10;
    }
    // Check if the original number is equal to its reversed version
    return original == reversed;
}

int main() {
    int num;
    printf("Enter any number: ");
    scanf("%d", &num);
    // Check if the number is a palindrome
    if (isPalindrome(num)) {
        printf("%d is a palindrome.\n", num);
    } else {
        printf("%d is not a palindrome.\n", num);
    }
    return 0;
}
