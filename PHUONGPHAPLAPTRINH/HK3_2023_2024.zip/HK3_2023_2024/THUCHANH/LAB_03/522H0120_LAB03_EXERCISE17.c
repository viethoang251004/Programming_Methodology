#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

bool isPerfect(int num) {
    int sum = 0;
    // Calculate the sum of proper divisors
    for (int i = 1; i <= num / 2; i++) {
        if (num % i == 0) {
            sum += i;
        }
    }
    // Check if the sum of divisors is equal to the original number
    return (sum == num);
}

//validate input
bool isValidInput(int num) {
    return num > 0;
}

int main() {
    int n;
    bool valid;
    //Input validation loop using do-while
    do {
        printf("Enter a positive integer greater than 0: ");
        valid = scanf("%d", &n) == 1 && isValidInput(n);

        if (!valid) {
            printf("Invalid input. Please enter a positive integer greater than 0.\n");
            // Clear the input buffer
            while (getchar() != '\n');
        }
    } while (!valid);

    printf("Perfect numbers between 1 and %d are:\n", n);

    //Using for loop
    // printf("Using for loop:\n");
    for (int i = 1; i <= n; i++) {
        if (isPerfect(i)) {
            printf("%d ", i);
        }
    }
    // printf("\n");

    // //Using while loop
    // printf("Using while loop:\n");
    // int i = 1;
    // while (i <= n) {
    //     if (isPerfect(i)) {
    //         printf("%d ", i);
    //     }
    //     i++;
    // }
    // printf("\n");

    // //Using do-while loop
    // printf("Using do-while loop:\n");
    // i = 1;
    // do {
    //     if (isPerfect(i)) {
    //         printf("%d ", i);
    //     }
    //     i++;
    // } while (i <= n);
    // printf("\n");
    return 0;
}