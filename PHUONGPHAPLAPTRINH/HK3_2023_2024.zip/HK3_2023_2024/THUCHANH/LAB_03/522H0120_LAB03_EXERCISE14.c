#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

int isPerfect(int num) {
    int sum = 0;
    // Calculate the sum of proper divisors
    for (int i = 1; i <= num / 2; i++) {
        if (num % i == 0) {
            sum += i;
        }
    }
    // Check if the sum of divisors is equal to the original number
    return (sum == num);
}

int main() {
    int num;
    printf("Enter any positive integer number: ");
    scanf("%d", &num);
    // Check if the number is a Perfect number
    if (isPerfect(num)) {
        printf("%d is a Perfect number.\n", num);
    } else {
        printf("%d is not a Perfect number.\n", num);
    }
    return 0;
}