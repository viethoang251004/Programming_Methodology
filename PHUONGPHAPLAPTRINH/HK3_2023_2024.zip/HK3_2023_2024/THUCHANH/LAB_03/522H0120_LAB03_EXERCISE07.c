#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int calculateProductOfDigits(int num, int product);

int main() {
    int num;
    printf("Enter any positive integer number: ");
    scanf("%d", &num);

    // if (num < 0) {
    //     num = -num;
    // }

    // while (num != 0) {
    //     remainder = num % 10;
    //     product *= remainder;
    //     num /= 10;
    // }

    printf("Product of the digits: %d\n", calculateProductOfDigits(num, 1));
    return calculateProductOfDigits(num, 1);
}

int calculateProductOfDigits(int num, int product) {
    int remainder = num;
    if (num < 0) {
        num = -num;
    }

    while (num != 0) {
        remainder = num % 10;
        product *= remainder;
        num /= 10;
    }
    return product;
}
