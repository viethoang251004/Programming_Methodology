#include <stdio.h>

void transposeMatrix(int mat[][100], int m, int n) {
    int transposed[100][100];

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            transposed[i][j] = mat[j][i];
        }
    }

    printf("Transpose of the matrix:\n");
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            printf("%d ", transposed[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int m, n;
    printf("Enter the number of rows (m): ");
    scanf("%d", &m);
    printf("Enter the number of columns (n): ");
    scanf("%d", &n);

    int matrix[100][100];

    printf("Enter elements of the matrix:\n");
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            scanf("%d", &matrix[i][j]);
        }
    }

    transposeMatrix(matrix, m, n);

    return 0;
}
