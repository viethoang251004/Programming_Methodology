#include <stdio.h>

void countDuplicates(int arr[], int size) {
    int freqMap[100] = {0}; // Assuming array elements are within [0, 99]
    for (int i = 0; i < size; ++i) {
        freqMap[arr[i]]++;
    }
    int duplicateCount = 0;
    for (int i = 0; i < 100; ++i) {
        if (freqMap[i] > 1) {
            printf("Element %d occurs %d times\n", i, freqMap[i]);
            duplicateCount++;
        }
    }
    printf("Total number of duplicate elements: %d\n", duplicateCount);
}

int main() {
    int myArray[] = {1, 2, 3, 2, 4, 3, 5, 5, 3, 9, 10, 4}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    countDuplicates(myArray, arraySize);
    return 0;
}