#include <stdio.h>

int sum_non_positive(int arr[], int size) {
    int sum = 0;
    for (int i = 0; i < size; ++i) {
        if (arr[i] <= 0) {
            sum += arr[i];
        }
    }
    return sum;
}

int main() {
    int my_array[] = {5, -2, 10, -7, 3, -12};
    int size = sizeof(my_array) / sizeof(my_array[0]);
    int result = sum_non_positive(my_array, size);
    printf("Sum of non-positive numbers: %d\n", result);
    return 0;
}
