#include <stdio.h>

void reverseArray(int arr[], int size) {
    for (int i = 0; i < size / 2; ++i) {
        // Swap arr[i] with arr[size - i - 1]
        int temp = arr[i];
        arr[i] = arr[size - i - 1];
        arr[size - i - 1] = temp;
    }
}

int main() {
    int myArray[] = {1, 2, 3, 4, 5}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    printf("Original array: ");
    for (int i = 0; i < arraySize; ++i) {
        printf("%d ", myArray[i]);
    }
    printf("\n");
    reverseArray(myArray, arraySize);
    printf("Reversed array: ");
    for (int i = 0; i < arraySize; ++i) {
        printf("%d ", myArray[i]);
    }
    printf("\n");
    return 0;
}
