#include <stdio.h>

void countFrequency(int arr[], int size) {
    int freqMap[100] = {0}; // Assuming array elements are within [0, 99]
    // Update the frequency map
    for (int i = 0; i < size; ++i) {
        freqMap[arr[i]]++;
    }
    // Print the frequency of each element
    for (int i = 0; i < 100; ++i) {
        if (freqMap[i] > 0) {
            printf("Element %d occurs %d times\n", i, freqMap[i]);
        }
    }
}

int main() {
    int myArray[] = {1, 2, 3, 2, 4, 3, 5, 5, 2, 7, 8, 10, 9}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    countFrequency(myArray, arraySize);
    return 0;
}
