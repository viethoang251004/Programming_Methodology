#include <stdio.h>

int searchElement(int arr[], int size, int key) {
    for (int i = 0; i < size; ++i) {
        if (arr[i] == key) {
            return i; // Return the index where the key is found
        }
    }
    return -1; // Key not found
}

int main() {
    int myArray[] = {10, 20, 30, 40, 50}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    int searchKey = 30; // Specify the key to search
    int result = searchElement(myArray, arraySize, searchKey);
    if (result != -1) {
        printf("Element %d found at index %d\n", searchKey, result);
    } else {
        printf("Element %d not found in the array\n", searchKey);
    }

    return 0;
}
