#include <stdio.h>

double sum_a(int n);
int sum_b(int n);
int factorial(int x);
int sum_c(int n);
int product_d(int n);
double product_e(int n);

int main() {
    int n = 5;  // Example value of n
    
    printf("Sum (a): %lf\n", sum_a(n));
    printf("Sum (b): %d\n", sum_b(n));
    printf("Sum (c): %d\n", sum_c(n));
    printf("Product (d): %d\n", product_d(n));
    printf("Product (e): %lf\n", product_e(n));

    return 0;
}

// a.
double sum_a(int n) {
    double sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i / 2.0;
    }
    return sum;
}

// b.
int sum_b(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += 2 * i + 1;
    }
    return sum;
}

// factorial function
int factorial(int x) {
    if (x == 0 || x == 1) {
        return 1;
    }
    return x * factorial(x - 1);
}

// c.
int sum_c(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += factorial(i) + 1;
    }
    return sum;
}

// d.
int product_d(int n) {
    int product = 1;
    for (int i = 1; i <= n; i++) {
        product *= factorial(i);
    }
    return product;
}

// e.
double product_e(int n) {
    double product = 1;
    for (int i = 1; i <= n; i++) {
        product *= (2 * i) / 3.0;
    }
    return product;
}

