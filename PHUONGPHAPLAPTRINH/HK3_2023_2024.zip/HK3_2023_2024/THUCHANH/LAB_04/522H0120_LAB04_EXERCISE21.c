#include <stdio.h>

// Function to calculate the determinant of a 3x3 matrix
double determinant3x3(double mat[3][3]) {
    double det = 0.0;

    // Calculate the determinant using the cofactor expansion formula
    det = mat[0][0] * (mat[1][1] * mat[2][2] - mat[1][2] * mat[2][1])
        - mat[0][1] * (mat[1][0] * mat[2][2] - mat[1][2] * mat[2][0])
        + mat[0][2] * (mat[1][0] * mat[2][1] - mat[1][1] * mat[2][0]);

    return det;
}

int main() {
    double matrix[3][3];

    printf("Enter the elements of the 3x3 matrix:\n");
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            scanf("%lf", &matrix[i][j]);
        }
    }

    double det = determinant3x3(matrix);

    printf("Determinant of the matrix: %.2lf\n", det);

    return 0;
}
