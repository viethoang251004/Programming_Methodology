#include <stdio.h>
int find_max(int arr[], int size) {
    if (size == 0) {
        // If the array is empty, return a special value or handle the error appropriately
        return size;
    }
    int max = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

int main() {
    int arr[] = {3, 5, 7, 2, 8, -1, 4, 10, 99};
    int size = sizeof(arr) / sizeof(arr[0]);
    int max = find_max(arr, size);
    if (max != -1) {
        printf("The maximum number in the array is: %d\n", max);
    } else {
        printf("The array is empty.\n");
    }
    return 0;
}
