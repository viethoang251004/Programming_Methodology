#include <stdio.h>

void deleteElement(int arr[], int *size, int position) {
    if (position < 0 || position >= *size) {
        printf("Invalid position. Element not deleted.\n");
        return;
    }
    // Shift elements to the left
    for (int i = position; i < *size - 1; ++i) {
        arr[i] = arr[i + 1];
    }
    (*size)--; // Reduce the array size
}

int main() {
    int myArray[] = {10, 20, 30, 40, 50}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    int positionToDelete = 2; // Specify the position (index) to delete
    printf("Original array: ");
    for (int i = 0; i < arraySize; ++i) {
        printf("%d ", myArray[i]);
    }
    printf("\n");
    deleteElement(myArray, &arraySize, positionToDelete);
    printf("Array after deletion: ");
    for (int i = 0; i < arraySize; ++i) {
        printf("%d ", myArray[i]);
    }
    printf("\n");
    return 0;
}
