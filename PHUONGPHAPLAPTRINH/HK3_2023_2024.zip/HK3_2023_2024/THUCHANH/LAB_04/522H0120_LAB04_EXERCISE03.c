#include <stdio.h>

int find_min(int arr[], int size) {
    int min = arr[0]; // Assume the first element is the minimum
    for (int i = 1; i < size; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }
    return min;
}

int main() {
    int arr[] = {3, 5, 7, 2, 8, 19, 4, 10, 12};
    int size = sizeof(arr) / sizeof(arr[0]);
    int min = find_min(arr, size);
    printf("The minimum number in the array is: %d\n", min);
    return 0;
}
