#include <stdio.h>
#include <stdbool.h>

//Compute factorial
unsigned long long factorial(int n) {
    // Base case
    if (n == 0) {
        return 1;
    }
    // Recursive case
    return n * factorial(n - 1);
}

int main() {
    int number = 5; // Example number
    printf("Factorial of %d is %llu\n", number, factorial(number));
    return 0;
}
