#include <stdio.h>
#include <stdbool.h>

//Perform recursion
bool is_prime_recursive(int n, int divisor) {
    // Base cases
    if (n < 2) {
        return false;
    }
    if (divisor == 1) {
        return true;
    }
    if (n % divisor == 0) {
        return false;
    }
    // Recursive call
    return is_prime_recursive(n, divisor - 1);
}

//Check if a number is prime
bool is_prime(int n) {
    return is_prime_recursive(n, n / 2);
}

int main() {
    int number = 7;
    if (is_prime(number)) {
        printf("%d is a prime number.\n", number);
    } else {
        printf("%d is not a prime number.\n", number);
    }
    return 0;
}
