#include <stdio.h>
#include <stdbool.h>

//Count the number of digits in a positive integer
int countDigits(int number) {
    //Base case: if the number is 0, we have no more digits to count
    if (number == 0) {
        return 0;
    }
    //Recursive case: divide the number by 10 to remove the last digit and add 1 to the count
    return 1 + countDigits(number / 10);
}

int main() {
    int number;
    printf("Enter a positive integer: ");
    scanf("%d", &number);
    if (number == 0) {
        printf("The number of digits in %d is 1\n", number);
    } else {
        // Compute the number of digits
        int digitCount = countDigits(number);
        printf("The number of digits in %d is %d\n", number, digitCount);
    }
    return 0;
}
