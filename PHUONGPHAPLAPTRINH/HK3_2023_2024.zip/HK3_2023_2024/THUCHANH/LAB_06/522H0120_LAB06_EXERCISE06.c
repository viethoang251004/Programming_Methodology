#include <stdio.h>
#include <stdbool.h>
#include <math.h>

// Function prototypes
int sumExpressionA(int n);
double sumExpressionB(int n);
int sumExpressionC(int n);
double sumExpressionD(int n);
unsigned long long productExpressionE(int n);

// Compute factorial
int factorial(int n);

int main() {
    int n;
    printf("Enter a positive integer n: ");
    scanf("%d", &n);
    // Compute the results
    int resultA = sumExpressionA(n);
    double resultB = sumExpressionB(n);
    int resultC = sumExpressionC(n);
    double resultD = sumExpressionD(n);
    unsigned long long resultE = productExpressionE(n);

    printf("a. Sum of (2i + 1) from 1 to %d: %d\n", n, resultA);
    printf("b. Sum of (i / 2) from 1 to %d: %lf\n", n, resultB);
    printf("c. Sum of (i!) from 1 to %d: %d\n", n, resultC);
    printf("d. Sum of sqrt(i) from 1 to %d: %lf\n", n, resultD);
    printf("e. Product of (i!) from 1 to %d: %llu\n", n, resultE);
    return 0;
}

// a. Sum of (2i + 1) from 1 to n
int sumExpressionA(int n) {
    if (n == 1) {
        return 2 * 1 + 1;
    }
    return (2 * n + 1) + sumExpressionA(n - 1);
}

// b. Sum of (i / 2) from 1 to n
double sumExpressionB(int n) {
    if (n == 1) {
        return 1 / 2.0;
    }
    return (n / 2.0) + sumExpressionB(n - 1);
}

// c. Sum of (i!) from 1 to n
int sumExpressionC(int n) {
    if (n == 1) {
        return factorial(1);
    }
    return factorial(n) + sumExpressionC(n - 1);
}

// d. Sum of sqrt(i) from 1 to n
double sumExpressionD(int n) {
    if (n == 1) {
        return sqrt(1);
    }
    return sqrt(n) + sumExpressionD(n - 1);
}

// e. Product of (i!) from 1 to n
unsigned long long productExpressionE(int n) {
    if (n == 1) {
        return factorial(1);
    }
    return factorial(n) * productExpressionE(n - 1);
}

// Helper function to compute factorial
int factorial(int n) {
    if (n == 1) {
        return 1;
    }
    return n * factorial(n - 1);
}
