#include <stdio.h>
#include <stdbool.h>

//Compute 2^n
unsigned long long power_of_two(int n) {
    // Base case
    if (n == 0) {
        return 1;
    }
    // Recursive case
    return 2 * power_of_two(n - 1);
}

int main() {
    int exponent = 5; // Example exponent
    printf("2^%d is %llu\n", exponent, power_of_two(exponent));
    return 0;
}
