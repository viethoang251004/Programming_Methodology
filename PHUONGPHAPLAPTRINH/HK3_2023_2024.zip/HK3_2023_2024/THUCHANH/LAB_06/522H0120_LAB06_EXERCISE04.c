#include <stdio.h>
#include <stdbool.h>

// Compute x^n
double power(double x, int n) {
    // Base case: any number to the power of 0 is 1
    if (n == 0) {
        return 1;
    }
    // If n is negative, we handle it by taking the reciprocal of the positive exponent
    else if (n < 0) {
        return 1 / power(x, -n);
    }
    // Recursive case: multiply x by the result of x raised to the power of (n-1)
    else {
        return x * power(x, n - 1);
    }
}

int main() {
    double x;
    int n;
    printf("Enter the base (x): ");
    scanf("%lf", &x);
    printf("Enter the exponent (n): ");
    scanf("%d", &n);
    // Compute x^n
    double result = power(x, n);
    printf("%lf to the power of %d is %lf\n", x, n, result);
    return 0;
}
