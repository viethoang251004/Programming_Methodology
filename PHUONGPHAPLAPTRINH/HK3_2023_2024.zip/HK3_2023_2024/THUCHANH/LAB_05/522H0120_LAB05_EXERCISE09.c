#include <stdio.h>
#include <string.h>

int main() {
    char s1[100], s2[100];
    printf("Enter the first string (s1): ");
    gets(s1);  // You can also use fgets(s1, sizeof(s1), stdin) for safer input
    printf("Enter the second string (s2): ");
    gets(s2);  // You can also use fgets(s2, sizeof(s2), stdin) for safer input
    char *pos = strstr(s1, s2);

    if (pos) {
        printf("The first position where s2 appears in s1 is: %ld\n", pos - s1);
    } else {
        printf("s2 does not appear in s1.\n");
    }
    return 0;
}
