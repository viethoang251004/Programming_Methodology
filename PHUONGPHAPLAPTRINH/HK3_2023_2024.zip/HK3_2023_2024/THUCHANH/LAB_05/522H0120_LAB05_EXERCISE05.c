#include <stdio.h>

void customConcatenate(char *s1, const char *s2) {
    while (*s1) {
        s1++;
    }
    while (*s2) {
        *s1 = *s2;
        s1++;
        s2++;
    }
    *s1 = '\0';
}

int main() {
    char s1[100] = "Hello, ";
    const char *s2 = "world!";
    customConcatenate(s1, s2);
    printf("Concatenated string: %s\n", s1);
    return 0;
}
