#include <stdio.h>
#include <string.h>

int main() {
    char s1[200], s2[100], result[300];
    int position;

    printf("Enter the first string (s1): ");
    fgets(s1, sizeof(s1), stdin);
    s1[strcspn(s1, "\n")] = 0;  // Remove newline character if present

    printf("Enter the second string (s2): ");
    fgets(s2, sizeof(s2), stdin);
    s2[strcspn(s2, "\n")] = 0;  // Remove newline character if present

    printf("Enter the position to insert s2 into s1: ");
    scanf("%d", &position);

    // Check if position is within the bounds of s1
    if (position < 0 || position > strlen(s1)) {
        printf("Invalid position.\n");
        return 1;
    }

    // Insert s2 into s1 at the specified position
    strncpy(result, s1, position);  // Copy first part of s1 to result
    result[position] = '\0';  // Null-terminate the result string
    strcat(result, s2);  // Append s2
    strcat(result, s1 + position);  // Append the remaining part of s1

    printf("The resulting string is: %s\n", result);
    return 0;
}
