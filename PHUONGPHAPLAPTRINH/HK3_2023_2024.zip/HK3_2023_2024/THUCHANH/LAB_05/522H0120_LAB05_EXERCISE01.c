#include <stdio.h>
#include <string.h>

#define SIZE 100

int getLength(const char *str) {
    int length = 0;
    while (str[length] != '\0' && str[length] != '\n') {
        length++;
    }
    return length;
}

int main() {
    char str[SIZE];
    printf("Enter a string: ");
    fgets(str, SIZE, stdin);

    printf("String: %s", str);
    printf("String's length: %d\n", getLength(str));

    return 0;
}
