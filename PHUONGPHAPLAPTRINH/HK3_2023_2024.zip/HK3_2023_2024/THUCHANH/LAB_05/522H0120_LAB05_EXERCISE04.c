#include <stdio.h>
#include <string.h>
#include <ctype.h>

void normalize_string(char *input) {
    int i, j;
    int length = strlen(input);
    int capitalize_next = 1;
    while (isspace((unsigned char)input[0])) {
        memmove(input, input + 1, strlen(input));
    }
    while (isspace((unsigned char)input[length - 1])) {
        input[length - 1] = '\0';
        length--;
    }
    for (i = 0; i < length; i++) {
        if (isspace((unsigned char)input[i])) {
            capitalize_next = 1;
        } else {
            if (capitalize_next) {
                input[i] = toupper((unsigned char)input[i]);
                capitalize_next = 0;
            } else {
                input[i] = tolower((unsigned char)input[i]);
            }
        }
    }
}

int main() {
    char input[100];
    printf("Enter a string: ");
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0';
    normalize_string(input);
    printf("Normalized string: %s\n", input);
    return 0;
}
