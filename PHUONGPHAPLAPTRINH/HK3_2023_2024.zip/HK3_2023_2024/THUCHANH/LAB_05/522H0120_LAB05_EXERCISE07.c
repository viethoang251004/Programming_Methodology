#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int* find_positions(char *input_string, char ch, int *count) {
    int length = strlen(input_string);
    int *positions = NULL;
    *count = 0;

    // Allocate memory for storing positions
    positions = (int*)malloc(length * sizeof(int));
    if (positions == NULL) {
        printf("Memory allocation failed.\n");
        return NULL;
    }

    for (int i = 0; i < length; i++) {
        if (input_string[i] == ch) {
            positions[*count] = i; // Store the index of the character
            (*count)++;
        }
    }

    // If no positions were found, return NULL
    if (*count == 0) {
        free(positions);
        return NULL;
    }

    return positions;
}

int main() {
    char input_string[100];
    char character;
    int count;

    printf("Enter a string: ");
    fgets(input_string, sizeof(input_string), stdin);
    // Remove newline character from input if present
    input_string[strcspn(input_string, "\n")] = '\0';
    // Prompt user for character to search
    printf("Enter a character to search: ");
    scanf(" %c", &character);
    // Find all positions of character in the input string
    int *positions = find_positions(input_string, character, &count);
    
    if (positions != NULL) {
        printf("The character '%c' appears at positions: ", character);
        for (int i = 0; i < count; i++) {
            printf("%d ", positions[i]);
        }
        printf("\n");

        // Free allocated memory
        free(positions);
    } else {
        printf("The character '%c' does not appear in the string.\n", character);
    }
    
    return 0;
}
