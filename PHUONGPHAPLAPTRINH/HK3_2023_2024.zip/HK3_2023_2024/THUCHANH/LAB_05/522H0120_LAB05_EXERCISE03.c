#include <stdio.h>
#include <string.h>

#define SIZE 100

int main() {
    char fullName[SIZE];
    printf("Enter your full name: ");
    fgets(fullName, SIZE, stdin);

    // Tokenize the full name
    char *firstName = strtok(fullName, " ");
    char *lastName = strtok(NULL, "\n"); // Remove newline character

    if (firstName && lastName) {
        printf("First Name: %s\n", firstName);
        printf("Last Name: %s\n", lastName);
    } else {
        printf("Invalid input. Please enter your full name.\n");
    }

    return 0;
}
