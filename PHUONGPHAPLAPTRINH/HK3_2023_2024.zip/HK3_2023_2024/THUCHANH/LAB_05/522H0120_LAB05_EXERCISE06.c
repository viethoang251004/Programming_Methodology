#include <stdio.h>
#include <string.h>

int first_occurrence(char *input_string, char ch) {
    int length = strlen(input_string); 
    for (int i = 0; i < length; i++) {
        if (input_string[i] == ch) {
            return i; // Return the index of the first occurrence
        }
    }
    return -1; // Return -1 if character is not found
}

int main() {
    char input_string[100];
    char character;
    printf("Enter a string: ");
    fgets(input_string, sizeof(input_string), stdin);
    // Remove newline character from input if present
    input_string[strcspn(input_string, "\n")] = '\0';
    // Prompt user for character to search
    printf("Enter a character to search: ");
    scanf(" %c", &character);
    // Find first occurrence of character in the input string
    int position = first_occurrence(input_string, character);
    if (position != -1) {
        printf("The character '%c' first appears at position %d.\n", character, position);
    } else {
        printf("The character '%c' does not appear in the string.\n", character);
    }
    return 0;
}
