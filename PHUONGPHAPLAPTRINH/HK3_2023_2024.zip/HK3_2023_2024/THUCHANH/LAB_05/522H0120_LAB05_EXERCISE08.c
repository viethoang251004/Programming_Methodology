#include <stdio.h>
#include <string.h>
#include <stdbool.h>

// Function to find the first occurrence of a word in a string
int find_word_position(const char *input_string, const char *word) {
    int input_length = strlen(input_string);
    int word_length = strlen(word);
    for (int i = 0; i <= input_length - word_length; i++) {
        // Check if the substring from input_string[i] matches the word
        if (strncmp(input_string + i, word, word_length) == 0) {
            return i; // Return the position of the first occurrence
        }
    }
    return -1; // Return -1 if word is not found
}

int main() {
    char input_string[100];
    char word[50];
    printf("Enter a string: ");
    fgets(input_string, sizeof(input_string), stdin);
    // Remove newline character from input if present
    input_string[strcspn(input_string, "\n")] = '\0';
    printf("Enter a word to search: ");
    scanf("%s", word);
    // Find first occurrence of word in the input string
    int position = find_word_position(input_string, word);
    if (position != -1) {
        printf("The word '%s' first appears at position %d.\n", word, position);
    } else {
        printf("The word '%s' does not appear in the string.\n", word);
    }    
    return 0;
}
