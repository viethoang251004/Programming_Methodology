#include <stdio.h>
#include <string.h>

int main() {
    char str[200];
    int n, position;

    printf("Enter the string: ");
    fgets(str, sizeof(str), stdin);
    str[strcspn(str, "\n")] = 0;  // Remove newline character if present

    printf("Enter the position to start deleting: ");
    scanf("%d", &position);
    printf("Enter the number of characters to delete: ");
    scanf("%d", &n);

    int len = strlen(str);

    // Check if position and n are within bounds
    if (position < 0 || position >= len || n < 0 || position + n > len) {
        printf("Invalid position or number of characters to delete.\n");
        return 1;
    }

    // Deleting n characters from position
    for (int i = position; i < len - n; i++) {
        str[i] = str[i + n];
    }
    str[len - n] = '\0';  // Null-terminate the string

    printf("The resulting string is: %s\n", str);
    return 0;
}
