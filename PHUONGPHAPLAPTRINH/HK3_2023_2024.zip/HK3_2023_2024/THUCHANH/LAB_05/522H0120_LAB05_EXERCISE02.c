#include <stdio.h>
#include <string.h>

#define SIZE 100

void printReverse(const char *str) {
    int length = strlen(str);
    for (int i = length - 1; i >= 0; i--) {
        printf("%c", str[i]);
    }
}

int main() {
    char str[SIZE];
    printf("Enter a string: ");
    fgets(str, SIZE, stdin);

    printf("String: %s", str);
    printf("String in reverse order: ");
    printReverse(str);

    return 0;
}
