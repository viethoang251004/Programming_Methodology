#include <stdio.h>

void taoFileInput(int m, int ei, int eg, int le, const char* w, int index) {
    char fileName[20];
    sprintf(fileName, "input%d.inp", index);
    FILE *file = fopen(fileName, "w");
    if (file != NULL) {
        fprintf(file, "%d %d %d %d %s\n", m, ei, eg, le, w);
        fclose(file);
    } else {
        printf("Error creating input file %s.\n", fileName);
    }
}

int main() {
    const char* weathers[] = {"Sunny", "Rain", "Wind", "Fog", "Cloud"};
    int index = 0;
    for (int m = 1; m <= 5; m++) {
        for (int ei = 1; ei <= 5; ei++) {
            for (int eg = 1; eg <= 5; eg++) {
                for (int le = 1; le <= 5; le++) {
                    for (int w = 0; w < 5; w++) {
                        taoFileInput(m, ei, eg, le, weathers[w], index);
                        index++;
                    }
                }
            }
        }
    }
    return 0;
}
