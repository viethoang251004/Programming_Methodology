#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdlib.h>
#define PI 3.14159265358979323846

//Đọc file input
void docFileInput(double *m, double *ei, double *eg, long *le, char *w) {
    FILE *file = fopen("input.inp", "r");
    if (file != NULL) {
        fscanf(file, "%lf %lf %lf %ld %s", m, ei, eg, le, w);
        fclose(file);
    } else {
        printf("Error opening input file.\n");
    }
}

// Ghi dữ liệu ra file output
void ghiDuLieuRaFileOutput(long soBanhItCoDuoc, long soBanhGaiCoDuoc, double soGaoConLai) {
    FILE *file = fopen("output.out", "w");
    if (file != NULL) {
        fprintf(file, "%ld\n", soBanhItCoDuoc); //Ghi số lượng cho bánh ít
        fprintf(file, "%ld\n", soBanhGaiCoDuoc); // Ghi số lượng cho bánh gai
        fprintf(file, "%.3lf\n", soGaoConLai); // Ghi số đơn vị gạo còn lại với 3 chữ số ở phần thập phân
        fclose(file);
    } else {
        printf("Error opening output file.\n");
    }
}

//Hàm main
int main() {
    //Khởi tạo biến cho các thuộc tính yêu cầu
    double m, ei, eg;
    long le;
    char w[10];
    //Đọc file input
    docFileInput(&m, &ei, &eg, &le, w);
    //Số lượng gạo và lá ban đầu cho bánh ít và bánh gai
    double soGaoChoBanhIt = pow(ei, 2) * pow(ei, 0.5);
    double soGaoChoBanhGai = (pow(eg, 2) * PI) / 4;
    long soLaChoBanhIt = (ei < 6) ? 1 : 2;
    long soLaChoBanhGai = (eg < 7) ? 1 : 2;
    //Thay đổi theo thời tiết
    if (strcmp(w, "Sunny") == 0) {
        soGaoChoBanhIt = soGaoChoBanhIt * 0.90;
        soGaoChoBanhGai = soGaoChoBanhGai * 1.15;
    } else if (strcmp(w, "Rain") == 0) {
        soGaoChoBanhIt = soGaoChoBanhIt * 1.15;
        soGaoChoBanhGai = soGaoChoBanhGai * 0.90;
    } else if (strcmp(w, "Wind") == 0) {
        soLaChoBanhIt = soLaChoBanhIt * 2;
        soLaChoBanhGai = soLaChoBanhGai * 2;
    } else if (strcmp(w, "Fog") == 0) {
        soLaChoBanhIt = (soLaChoBanhIt / 2 < 1) ? 1 : soLaChoBanhIt / 2;
        soLaChoBanhGai = (soLaChoBanhGai / 2 < 1) ? 1 : soLaChoBanhGai / 2;
    }
    //Tính số lượng bánh ít và bánh gai có thể làm được
    long soBanhItCoDuoc = 0, soBanhGaiCoDuoc = 0;
    double soGaoConLai = m;
    long soLaConLai = le;

    long maxBanhIt = (long)(m / soGaoChoBanhIt);
    long maxBanhGai = (long)(m / soGaoChoBanhGai);
    long bestSoBanhIt = 0, bestSoBanhGai = 0;
    double bestSoGaoConLai = m;

    for (long i = 0; i <= maxBanhIt; i++) {
        for (long j = 0; j <= maxBanhGai; j++) {
            double gaoCanThiet = i * soGaoChoBanhIt + j * soGaoChoBanhGai;
            long laCanThiet = i * soLaChoBanhIt + j * soLaChoBanhGai;
            if (gaoCanThiet <= m && laCanThiet <= le) {
                long totalBanh = i + j;
                double gaoConLai = m - gaoCanThiet;
                if (totalBanh > bestSoBanhIt + bestSoBanhGai || 
                    (totalBanh == bestSoBanhIt + bestSoBanhGai && gaoConLai < bestSoGaoConLai)) {
                    bestSoBanhIt = i;
                    bestSoBanhGai = j;
                    bestSoGaoConLai = gaoConLai;
                }
            }
        }
    }
    // Ghi dữ liệu vào file output
    ghiDuLieuRaFileOutput(bestSoBanhIt, bestSoBanhGai, bestSoGaoConLai);
    return 0;
}
