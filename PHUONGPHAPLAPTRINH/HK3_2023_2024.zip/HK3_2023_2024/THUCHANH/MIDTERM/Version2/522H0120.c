#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdlib.h>
#define PI 3.14159265358979323846
//Doc file input
void docFileInput(double *m, double *ei, double *eg, long *le, char *w) {
    FILE *file = fopen("input.inp", "r");
    if (file != NULL) {
        fscanf(file, "%lf %lf %lf %ld %s", m, ei, eg, le, w);
        fclose(file);
    } else {
        printf("Error opening input file.\n");
    }
}
//Ghi du lieu ra file output
void ghiDuLieuRaFileOutput(long soBanhItCoDuoc, long soBanhGaiCoDuoc, double soGaoConLai) {
    FILE *file = fopen("output.out", "w");
    if (file != NULL) {
        fprintf(file, "%ld %ld %lf\n", soBanhItCoDuoc, soBanhGaiCoDuoc, soGaoConLai);
        fclose(file);
    } else {
        printf("Error opening output file.\n");
    }
}
//Ham main
int main() {
    //Khoi tao bien cho cac thuoc tinh yc trong de
    double m, ei, eg;
    long le;
    char w[10];
    //Doc file input
    docFileInput(&m, &ei, &eg, &le, w);
    //So luong gao va la ban dau cho banh it va banh gai
    double soGaoChoBanhIt =pow(ei, 2)*pow(ei, 0.5);
    double soGaoChoBanhGai =(pow(eg, 2)*PI)/4;

    long soLaChoBanhIt= (ei < 6) ? 1 : 2;
    long soLaChoBanhGai =(eg < 7) ? 1 : 2;

    // Thay doi theo thoi tiet
    if (strcmp(w, "Sunny")==0) {
        soGaoChoBanhIt =soGaoChoBanhIt*0.90;
        soGaoChoBanhGai = soGaoChoBanhGai*1.15;
    } else if (strcmp(w, "Rain")==0) {
        soGaoChoBanhIt =soGaoChoBanhIt*1.15;
        soGaoChoBanhGai =soGaoChoBanhGai*0.90;
    } else if (strcmp(w, "Wind")==0) {
        soLaChoBanhIt= soLaChoBanhIt*2;
        soLaChoBanhGai= soLaChoBanhGai*2;
    } else if (strcmp(w, "Fog")==0) {
        soLaChoBanhIt = (soLaChoBanhIt / 2 < 1) ? 1 : soLaChoBanhIt/2;
        soLaChoBanhGai =(soLaChoBanhGai / 2 < 1) ? 1 : soLaChoBanhGai/2;
    }

    //Tính số lượng bánh ít và bánh gai có thể làm được dựa trên information của file input
    long soBanhItCoDuoc=0, soBanhGaiCoDuoc=0;
    double soGaoConLai=m;
    long soLaConLai=le;

    while (soGaoConLai>=soGaoChoBanhIt && soLaConLai>=soLaChoBanhIt) {
        soGaoConLai= soGaoConLai-soGaoChoBanhIt;
        soLaConLai =soLaConLai-soLaChoBanhIt;
        soBanhItCoDuoc++;
    }
    while (soGaoConLai>=soGaoChoBanhGai && soLaConLai>=soLaChoBanhGai) {
        soGaoConLai =soGaoConLai-soGaoChoBanhGai;
        soLaConLai =soLaConLai-soLaChoBanhGai;
        soBanhGaiCoDuoc++;
    }
    //Ghi du lieu vao file output
    ghiDuLieuRaFileOutput(soBanhItCoDuoc, soBanhGaiCoDuoc, soGaoConLai);
    return 0;
}