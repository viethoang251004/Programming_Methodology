// #include <stdio.h>
// #include <string.h>
// #include <math.h>

// #define PI 3.14159265358979323846

// void docFileInput(double *m, double *ei, double *eg, long *le, char *w) {
//     FILE *file = fopen("input.inp", "r");
//     if (file != NULL) {
//         fscanf(file, "%lf %lf %lf %ld %s", m, ei, eg, le, w);
//         fclose(file);
//     } else {
//         printf("Error opening input file.\n");
//     }
// }

// void ghiDuLieuRaFileOutput(long soBanhItCoDuoc, long soBanhGaiCoDuoc, double soGaoConLai) {
//     FILE *file = fopen("output.out", "w");
//     if (file != NULL) {
//         fprintf(file, "%ld %ld %lf\n", soBanhItCoDuoc, soBanhGaiCoDuoc, soGaoConLai);
//         fclose(file);
//     } else {
//         printf("Error opening output file.\n");
//     }
// }

// int main() {
//     double m, ei, eg;
//     long le;
//     char w[10];

//     docFileInput(&m, &ei, &eg, &le, w);

//     double soGaoChoBanhIt = pow(ei, 2) * pow(ei, 0.5);
//     double soGaoChoBanhGai = (pow(eg, 2) * PI) / 4;

//     long soLaChoBanhIt = (ei < 6) ? 1 : 2;
//     long soLaChoBanhGai = (eg < 7) ? 1 : 2;

//     if (strcmp(w, "Sunny") == 0) {
//         soGaoChoBanhIt *= 0.90;
//         soGaoChoBanhGai *= 1.15;
//     } else if (strcmp(w, "Rain") == 0) {
//         soGaoChoBanhIt *= 1.15;
//         soGaoChoBanhGai *= 0.90;
//     } else if (strcmp(w, "Wind") == 0) {
//         soLaChoBanhIt *= 2;
//         soLaChoBanhGai *= 2;
//     } else if (strcmp(w, "Fog") == 0) {
//         soLaChoBanhIt = (soLaChoBanhIt / 2 < 1) ? 1 : soLaChoBanhIt / 2;
//         soLaChoBanhGai = (soLaChoBanhGai / 2 < 1) ? 1 : soLaChoBanhGai / 2;
//     }

//     long soBanhItCoDuoc = 0, soBanhGaiCoDuoc = 0;
//     double soGaoConLai = m;
//     long soLaConLai = le;

//     long maxBanhIt = (long)(m / soGaoChoBanhIt);
//     long maxBanhGai = (long)(m / soGaoChoBanhGai);
//     long bestSoBanhIt = 0, bestSoBanhGai = 0;
//     long bestTotalBanh = 0;

//     for (long i = 0; i <= maxBanhIt; i++) {
//         for (long j = 0; j <= maxBanhGai; j++) {
//             double gaoCanThiet = i * soGaoChoBanhIt + j * soGaoChoBanhGai;
//             long laCanThiet = i * soLaChoBanhIt + j * soLaChoBanhGai;
//             if (gaoCanThiet <= m && laCanThiet <= le) {
//                 long totalBanh = i + j;
//                 if (totalBanh > bestTotalBanh) {
//                     bestTotalBanh = totalBanh;
//                     bestSoBanhIt = i;
//                     bestSoBanhGai = j;
//                     soGaoConLai = m - gaoCanThiet;
//                 }
//             }
//         }
//     }

//     ghiDuLieuRaFileOutput(bestSoBanhIt, bestSoBanhGai, soGaoConLai);
//     return 0;
// }



// #include <stdio.h>
// #include <stdlib.h>
// #include <math.h>
// #include <string.h>

// #define PI 3.14159265358979323846

// void docFileInput(double *m, double *ei, double *eg, long *le, char *w) {
//     FILE *file = fopen("input13.inp", "r");
//     if (file != NULL) {
//         fscanf(file, "%lf %lf %lf %ld %s", m, ei, eg, le, w);
//         fclose(file);
//     } else {
//         printf("Error opening input file.\n");
//     }
// }

// void ghiDuLieuRaFileOutput(long soBanhItCoDuoc, long soBanhGaiCoDuoc, double soGaoConLai) {
//     FILE *file = fopen("output13.out", "w");
//     if (file != NULL) {
//         fprintf(file, "%ld %ld %lf\n", soBanhItCoDuoc, soBanhGaiCoDuoc, soGaoConLai);
//         fclose(file);
//     } else {
//         printf("Error opening output file.\n");
//     }
// }

// int main() {
//     int ms[] = {1, 2, 3, 4, 5};
//     int eis[] = {1, 2, 3, 4, 5};
//     int egs[] = {1, 2, 3, 4, 5};
//     int les[] = {1, 2, 3, 4, 5};
//     char *weathers[] = {"Sunny", "Rain", "Wind", "Fog", "Cloud"};
//     int total = 3125;
//     int index = 0;

//     for (int m = 0; m < 5; m++) {
//         for (int ei = 0; ei < 5; ei++) {
//             for (int eg = 0; eg < 5; eg++) {
//                 for (int le = 0; le < 5; le++) {
//                     for (int w = 0; w < 5; w++) {
//                         char inputFilename[20];
//                         char outputFilename[20];
//                         sprintf(inputFilename, "input%d.inp", index);
//                         sprintf(outputFilename, "output%d.out", index);

//                         FILE *inputFile = fopen(inputFilename, "w");
//                         if (inputFile != NULL) {
//                             fprintf(inputFile, "%d %d %d %d %s\n", ms[m], eis[ei], egs[eg], les[le], weathers[w]);
//                             fclose(inputFile);
//                         } else {
//                             printf("Error creating input file %d\n", index);
//                         }

//                         // Rename input file to input13.inp
//                         rename(inputFilename, "input13.inp");

//                         // Run the main program logic
//                         double m_val, ei_val, eg_val;
//                         long le_val;
//                         char w_val[10];
                        
//                         docFileInput(&m_val, &ei_val, &eg_val, &le_val, w_val);

//                         double soGaoChoBanhIt = pow(ei_val, 2) * pow(ei_val, 0.5);
//                         double soGaoChoBanhGai = (pow(eg_val, 2) * PI) / 4;

//                         long soLaChoBanhIt = (ei_val < 6) ? 1 : 2;
//                         long soLaChoBanhGai = (eg_val < 7) ? 1 : 2;

//                         if (strcmp(w_val, "Sunny") == 0) {
//                             soGaoChoBanhIt *= 0.90;
//                             soGaoChoBanhGai *= 1.15;
//                         } else if (strcmp(w_val, "Rain") == 0) {
//                             soGaoChoBanhIt *= 1.15;
//                             soGaoChoBanhGai *= 0.90;
//                         } else if (strcmp(w_val, "Wind") == 0) {
//                             soLaChoBanhIt *= 2;
//                             soLaChoBanhGai *= 2;
//                         } else if (strcmp(w_val, "Fog") == 0) {
//                             soLaChoBanhIt = (soLaChoBanhIt / 2 < 1) ? 1 : soLaChoBanhIt / 2;
//                             soLaChoBanhGai = (soLaChoBanhGai / 2 < 1) ? 1 : soLaChoBanhGai / 2;
//                         }

//                         long soBanhItCoDuoc = 0, soBanhGaiCoDuoc = 0;
//                         double soGaoConLai = m_val;
//                         long soLaConLai = le_val;

//                         long maxBanhIt = (long)(m_val / soGaoChoBanhIt);
//                         long maxBanhGai = (long)(m_val / soGaoChoBanhGai);
//                         long bestSoBanhIt = 0, bestSoBanhGai = 0;
//                         long bestTotalBanh = 0;

//                         for (long i = 0; i <= maxBanhIt; i++) {
//                             for (long j = 0; j <= maxBanhGai; j++) {
//                                 double gaoCanThiet = i * soGaoChoBanhIt + j * soGaoChoBanhGai;
//                                 long laCanThiet = i * soLaChoBanhIt + j * soLaChoBanhGai;
//                                 if (gaoCanThiet <= m_val && laCanThiet <= le_val) {
//                                     long totalBanh = i + j;
//                                     if (totalBanh > bestTotalBanh) {
//                                         bestTotalBanh = totalBanh;
//                                         bestSoBanhIt = i;
//                                         bestSoBanhGai = j;
//                                         soGaoConLai = m_val - gaoCanThiet;
//                                     }
//                                 }
//                             }
//                         }

//                         ghiDuLieuRaFileOutput(bestSoBanhIt, bestSoBanhGai, soGaoConLai);

//                         // Rename output file
//                         rename("output13.out", outputFilename);

//                         // Restore the input file name
//                         rename("input13.inp", inputFilename);

//                         index++;
//                     }
//                 }
//             }
//         }
//     }

//     return 0;
// }


#include <stdio.h>
#include <string.h>
#include <math.h>

#define PI 3.14159265358979323846

void docFileInput(double *m, double *ei, double *eg, long *le, char *w) {
    FILE *file = fopen("input.inp", "r");
    if (file != NULL) {
        fscanf(file, "%lf %lf %lf %ld %s", m, ei, eg, le, w);
        fclose(file);
    } else {
        printf("Error opening input file.\n");
    }
}

void ghiDuLieuRaFileOutput(long soBanhItCoDuoc, long soBanhGaiCoDuoc, double soGaoConLai) {
    FILE *file = fopen("output.out", "w");
    if (file != NULL) {
        fprintf(file, "%ld %ld %lf\n", soBanhItCoDuoc, soBanhGaiCoDuoc, soGaoConLai);
        fclose(file);
    } else {
        printf("Error opening output file.\n");
    }
}

int main() {
    double m, ei, eg;
    long le;
    char w[10];

    docFileInput(&m, &ei, &eg, &le, w);

    double soGaoChoBanhIt = pow(ei, 2) * pow(ei, 0.5);
    double soGaoChoBanhGai = (pow(eg, 2) * PI) / 4;

    long soLaChoBanhIt = (ei < 6) ? 1 : 2;
    long soLaChoBanhGai = (eg < 7) ? 1 : 2;

    if (strcmp(w, "Sunny") == 0) {
        soGaoChoBanhIt *= 0.90;
        soGaoChoBanhGai *= 1.15;
    } else if (strcmp(w, "Rain") == 0) {
        soGaoChoBanhIt *= 1.15;
        soGaoChoBanhGai *= 0.90;
    } else if (strcmp(w, "Wind") == 0) {
        soLaChoBanhIt *= 2;
        soLaChoBanhGai *= 2;
    } else if (strcmp(w, "Fog") == 0) {
        soLaChoBanhIt = (soLaChoBanhIt / 2 < 1) ? 1 : soLaChoBanhIt / 2;
        soLaChoBanhGai = (soLaChoBanhGai / 2 < 1) ? 1 : soLaChoBanhGai / 2;
    }

    long soBanhItCoDuoc = 0, soBanhGaiCoDuoc = 0;
    double soGaoConLai = m;
    long soLaConLai = le;

    long maxBanhIt = (long)(m / soGaoChoBanhIt);
    long maxBanhGai = (long)(m / soGaoChoBanhGai);
    long bestSoBanhIt = 0, bestSoBanhGai = 0;
    long bestTotalBanh = 0;

    for (long i = 0; i <= maxBanhIt; i++) {
        for (long j = 0; j <= maxBanhGai; j++) {
            double gaoCanThiet = i * soGaoChoBanhIt + j * soGaoChoBanhGai;
            long laCanThiet = i * soLaChoBanhIt + j * soLaChoBanhGai;
            if (gaoCanThiet <= m && laCanThiet <= le) {
                long totalBanh = i + j;
                if (totalBanh > bestTotalBanh) {
                    bestTotalBanh = totalBanh;
                    bestSoBanhIt = i;
                    bestSoBanhGai = j;
                    soGaoConLai = m - gaoCanThiet;
                }
            }
        }
    }

    ghiDuLieuRaFileOutput(bestSoBanhIt, bestSoBanhGai, soGaoConLai);
    return 0;
}
