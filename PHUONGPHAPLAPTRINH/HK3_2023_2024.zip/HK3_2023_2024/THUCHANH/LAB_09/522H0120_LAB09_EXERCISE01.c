#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main() {
    FILE *inputFile, *outputFile;
    int numbers[20];
    int sum = 0;

    inputFile = fopen("input01.txt", "r"); // mở file input01.txt để đọc
    if (inputFile == NULL) {
        printf("Could not open input file.\n"); // nếu đọc không được thì in ra lỗi
        return 1;
    }
    // Đọc 20 số nguyên trong file input01.txt để tính tổng
    for (int i = 0; i < 20; i++) {
        fscanf(inputFile, "%d", &numbers[i]);
        sum += numbers[i];
    }
    //Đóng file input01.txt sau khi tính xong
    fclose(inputFile);
    // Mở file output để ghi kết quả vừa tính được
    outputFile = fopen("output01.txt", "w");
    if (outputFile == NULL) {
        printf("Could not open output file.\n");
        return 1;
    }
    //Ghi tổng vừa tính được vào file output
    fprintf(outputFile, "Sum: %d\n", sum);
    //Đóng file output.txt sau khi ghi xong
    fclose(outputFile);
    // In dòng thông báo cho người dùng biết là đã ghi xong kết quả vào file output
    printf("The sum has been written to output01.txt\n");
    return 0;
}
