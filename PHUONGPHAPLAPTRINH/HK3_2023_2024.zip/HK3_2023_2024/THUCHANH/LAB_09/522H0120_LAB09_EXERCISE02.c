#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main() {
    FILE *inputFile, *outputFile;
    char strings[5][100];
    int lengths[5];

    inputFile = fopen("input02.txt", "r"); // mở file input02.txt để đọc
    if (inputFile == NULL) {
        printf("Could not open input file.\n"); // nếu đọc không được thì in ra lỗi
        return 1;
    }
    //Đọc 5 chuỗi trong file input02.txt để tính độ dài của mỗi chuỗi
    for (int i = 0; i < 5; i++) {
        fgets(strings[i], sizeof(strings[i]), inputFile);
        // Loại bỏ ký tự xuống dòng nếu có
        strings[i][strcspn(strings[i], "\n")] = '\0';
        lengths[i] = strlen(strings[i]);
    }
    // Đóng file input
    fclose(inputFile);
    //Mở file output để ghi dữ liệu
    outputFile = fopen("output02.txt", "w");
    if (outputFile == NULL) {
        printf("Could not open output file.\n");
        return 1;
    }
    // Ghi độ dài của từng chuỗi vào file output
    for (int i = 0; i < 5; i++) {
        fprintf(outputFile, "Length of string %d: %d\n", i + 1, lengths[i]);
    }
    // Đóng file output
    fclose(outputFile);
    printf("The lengths of the strings have been written to output02.txt\n");
    return 0;
}
