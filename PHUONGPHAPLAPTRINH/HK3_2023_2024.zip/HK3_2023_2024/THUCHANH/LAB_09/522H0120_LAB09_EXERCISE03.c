#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int linearSearch(int arr[], int size, int target);
int binarySearch(int arr[], int size, int target);
int main() {
    char filename[100];
    FILE *file;
    int arr[100];
    int size = 0;
    int choice, target, result;

    printf("Enter a filename: ");
    scanf("%s", filename);
    //Open the file and read the numbers into the array
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open file %s\n", filename);
        return 1;
    }
    while (fscanf(file, "%d", &arr[size]) != EOF && size < 100) {
        size++;
    }
    fclose(file);

    printf("Choose one of these search algorithms:\n");
    printf("1. Linear Search\n");
    printf("2. Binary Search\n");
    // Read a letter or number indicating the algorithm
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter a value to search for: ");
    scanf("%d", &target);
    //Perform the search based on the user's choice
    if (choice == 1) {
        result = linearSearch(arr, size, target);
    } else if (choice == 2) {
        result = binarySearch(arr, size, target);
    } else {
        printf("Invalid choice\n");
        return 1;
    }

    if (result == -1) {
        printf("Not found\n");
    } else {
        printf("Found at position %d\n", result);
    }

    return 0;
}
// Linear search algorithm
int linearSearch(int arr[], int size, int target) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == target) {
            return i;
        }
    }
    return -1;
}
//Binary search algorithm
int binarySearch(int arr[], int size, int target) {
    int left = 0;
    int right = size - 1;
    
    while (left <= right) {
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid;
        }
        if (arr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1;
}
