#include <stdio.h>

int main(int argc, char *argv[])
{
    int total_days, days, weeks, years;
    printf("Nhập tổng số ngày: ");
    scanf("%d", &total_days);
    years = total_days / 365;
    days = total_days % 365;
    weeks = days / 7;
    days = days % 7;
    printf("Số năm sau khi được chuyển đổi: %d", years);
    printf("\nSố tuần còn lại sau khi chuyển đổi năm: %d", weeks);
    printf("\nSố ngày còn lại sau khi chuyển đổi năm và đã biết số tuần còn lại: %d", days);
    printf("\nSố giờ có được tương đương với số năm của người dùng nhập vào: %d", total_days * 24);
    return 0;
}   