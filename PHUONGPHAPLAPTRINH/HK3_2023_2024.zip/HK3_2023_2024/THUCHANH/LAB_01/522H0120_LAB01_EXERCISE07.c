#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int year;
    // int result;
    printf("Nhập số năm để kiểm tra: ");
    scanf("%d", &year);
    if (year % 4 == 0) {
        if (year % 100 == 0) {
            if (year % 400 == 0) {
                printf("Đây là năm nhuận!");
            } else {
                printf("Đây không phải là năm nhuận!");
            }
        } else {
            printf("Đây không phải là năm nhuận!");
        }
    } else {
        printf("Đây không phải là năm nhuận!");
    }
    
    return 0;
}