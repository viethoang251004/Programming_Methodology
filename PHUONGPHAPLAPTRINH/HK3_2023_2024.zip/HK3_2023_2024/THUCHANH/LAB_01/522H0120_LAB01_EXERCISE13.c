#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

float main()
{
    float physics_mark, chemistry_mark, biology_mark, mathematics_mark, computer_mark;
    float result;
    printf("Nhập điểm của 5 môn dựa trên đề bài yêu cầu: ");
    scanf("%f %f %f %f %f", &physics_mark, &chemistry_mark, &biology_mark, &mathematics_mark, &computer_mark);
    if (physics_mark <= 100 && chemistry_mark <= 100 && biology_mark <= 100 && mathematics_mark <= 100 && computer_mark <= 100)
    {
        result = (physics_mark + chemistry_mark + biology_mark + mathematics_mark + computer_mark) / 5.0;
        printf("%.2f%%\n", result);
        if (result > 90)
        {
            printf("Grade A");
        }
        else if (result > 80)
        {
            printf("Grade B");
        }
        else if (result > 70)
        {
            printf("Grade C");
        }
        else if (result > 60)
        {
            printf("Grade D");
        }
        else if (result > 40)
        {
            printf("Grade E");
        }
        else if (result < 40)
        {
            printf("Grade F");
        }
    } else {
        printf("Điểm không hợp lệ. Vui lòng nhập lại!");
    }
}