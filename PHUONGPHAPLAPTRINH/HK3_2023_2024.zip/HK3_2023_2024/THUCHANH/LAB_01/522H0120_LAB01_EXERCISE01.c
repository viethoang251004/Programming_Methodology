#include <stdio.h>

void main(){
    printf("Nguyễn Đình Việt Hoàng\n");
    printf("25/10/2004\n");
    printf("0764251004");
}