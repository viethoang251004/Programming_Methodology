// #include <stdio.h>
// #include <string.h>
// #include <math.h>
// #include <stdlib.h>

// int main() {
//     int num1, num2, num3;
//     int max = num1;
//     printf("Nhập số nguyên thứ nhất: ");
//     scanf("%d", &num1);
//     printf("Nhập số nguyên thứ hai: ");
//     scanf("%d", &num2);
//     printf("Nhập số nguyên thứ ba: ");
//     scanf("%d", &num3);
//     // if (num1 > num2 && num1 > num3) {
//     //     printf("Số nguyên thứ nhất là số nguyên lớn nhất!\n");
//     // }
//     // if (num1 > num2 && num1 < num3) {
//     //     printf("Số nguyên thứ ba là số nguyên lớn nhất!\n");
//     // }
//     // if (num1 < num2 && num1 > num3) {
//     //     printf("Số nguyên thứ hai là số nguyên lớn nhất!\n");
//     // }
//     // if (num1 < num2 && num1 < num3 && num2 < num3) {
//     //     printf("Số nguyên thứ ba là số nguyên lớn nhất!\n");
//     // }
//     // if (num2 > num1 && num2 > num3) {
//     //     printf("Số nguyên thứ hai là số nguyên lớn nhất!\n");
//     // }
//     // if (num2 > num1 && num2 < num3) {
//     //     printf("Số nguyên thứ ba là số nguyên lớn nhất!\n");
//     // }
//     // if (num2 < num1 &&)
//     return 0;
// }

#include <stdio.h>

int main() {
    int num1, num2, num3;
    printf("Nhập 3 số nguyên bất kỳ: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    if(num1 >= num2 && num1 >= num3) {
        printf("Số nguyên lớn nhất là %d\n", num1);
    }
    else if(num2 >= num1 && num2 >= num3) {
        printf("Số nguyên lớn nhất là %d\n", num2);
    }
    else {
        printf("Số nguyên lớn nhất là %d\n", num3);
    }

    return 0;
}
