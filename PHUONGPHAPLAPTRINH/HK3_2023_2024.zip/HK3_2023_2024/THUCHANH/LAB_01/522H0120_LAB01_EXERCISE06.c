#include <stdio.h>
#include <math.h>
#include <stdlib.h>

float main(){
    int number;
    int result;
    printf("Nhập một số bất kỳ: ");
    scanf("%d", &number);
    result = abs(number);
    printf("Giá trị tuyệt đối của số đã nhập là: %d", result);
    return result;
}
