#include <stdio.h>
#include <ctype.h>

char main() {
    char character;
    printf("Nhập một ký tự bất kỳ: ");
    scanf("%c", &character);

    if (isalnum(character)) {      // isalnum thuộc thư viện ctype.h
        printf("Ký tự '%c' thuộc tập hợp ký tự số và chữ.\n", character);
    } else {
        printf("Ký tự '%c' không thuộc tập hợp ký tự số và chữ.\n", character);
    }

    return character;
}
