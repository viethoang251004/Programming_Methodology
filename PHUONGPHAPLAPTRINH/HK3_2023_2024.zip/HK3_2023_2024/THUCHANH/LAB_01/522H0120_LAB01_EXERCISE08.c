#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int num1, num2;
    printf("Nhập số nguyên thứ nhất: ");
    scanf("%d", &num1);
    printf("Nhập số nguyên thứ hai: ");
    scanf("%d", &num2);
    if (num1 > num2) {
        printf("Số nguyên thứ nhất là số nguyên lớn nhất!\n");
    }
    if (num1 < num2) {
        printf("Số nguyên thứ hai là số nguyên lớn nhất!\n");
    }
    if (num1 == num2) {
        printf("Không có số nguyên nào lớn nhất!\n");
    }
    return 0;
}