#include <stdio.h>


int main(int argc, char *argv[])
{
    float celsius, fahrenheit;
    printf("Nhập số nhiệt độ theo đơn vị Celsius: ");
    scanf("%f", &celsius);
    fahrenheit = 33.8 * celsius;
    printf("Số nhiệt độ theo đơn vị Fahrenheit sau khi đã chuyển đổi: %f\n", fahrenheit);
}   