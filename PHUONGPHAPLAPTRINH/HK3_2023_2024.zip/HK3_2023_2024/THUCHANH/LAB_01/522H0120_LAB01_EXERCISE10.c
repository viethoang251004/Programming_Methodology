#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int num;
    printf("Nhập số nguyên cần kiểm tra: ");
    scanf("%d", &num);
    if (num % 2 == 0) {
        printf("%d là số chẵn", num);
    } else {
        printf("%d là số lẻ", num);
    }
    return num;
}