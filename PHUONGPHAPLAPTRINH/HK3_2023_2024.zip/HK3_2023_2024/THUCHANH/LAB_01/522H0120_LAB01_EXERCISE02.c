#include <stdio.h>

void main(){
    int a, b;
    int result_addition, result_subtraction, result_multiplication, result_division, result_remainder;
    printf("Nhập số nguyên thứ nhất: ");
    scanf("%d",&a);
    printf("Nhập số nguyên thứ hai: ");
    scanf("%d", &b);
    result_addition = a + b;
    result_subtraction = a - b;
    result_multiplication = a * b;
    result_division = a / b;
    result_remainder = a % b;
    printf("Tổng hai số nguyên: %d\n", result_addition);
    printf("Hiệu hai số nguyên: %d\n", result_subtraction);
    printf("Tích hai số nguyên: %d\n", result_multiplication);
    printf("Chia lấy phần nguyên hai số nguyên: %d\n", result_division);
    printf("Chia lấy phần dư hai số nguyên: %d", result_remainder);
}