#include <stdio.h>
#include <math.h>

float main(){
    float height, width;
    float perimeter_rectangle, area_rectangle;
    printf("Nhập chiều dài hình chữ nhật: ");
    scanf("%f",&height);
    printf("Nhập chiều rộng hình chữ nhật: ");
    scanf("%f", &width);
    perimeter_rectangle = 2 * (height + width);
    area_rectangle = height * width;
    printf("Chu vi hình chữ nhật là: %.2f\n", perimeter_rectangle);
    printf("Diện tích hình chữ nhật là: %.2f\n", area_rectangle);
    return perimeter_rectangle, area_rectangle;
}
