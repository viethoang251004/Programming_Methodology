#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int angle1, angle2, angle3;
    int result;
    printf("Nhập 3 góc bất kỳ của một tam giác: ");
    scanf("%d %d %d", &angle1, &angle2, &angle3);
    result = angle1 + angle2 + angle3;
    if (result == 180) {
        printf("Đây là một tam giác!\n");
    } else {
        printf("Đây không phải là một tam giác!\n");
    }
}