#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int number, sum = 0, digit;
    printf("Enter any number: ");
    scanf("%d", &number);
    while (number != 0) {
        digit = number % 10;  // Extract the last digit
        sum += digit;         // Add the digit to sum
        number = number / 10; // Remove the last digit
    }
    printf("Sum of digits: %d\n", sum);
    return 0;
}
