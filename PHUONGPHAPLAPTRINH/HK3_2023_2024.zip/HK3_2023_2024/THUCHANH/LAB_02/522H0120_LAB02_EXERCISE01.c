    #include <stdio.h>
    #include <string.h>
    #include <math.h>
    #include <stdlib.h>

    int nhanGiaTriDauVaoHopLe();
    int tinhTongBangVongLapFor(int n);
    int tinhTongBangVongLapWhile(int n);
    int tinhTongBangVongLapDoWhile(int n);

    int main() {
        int n = nhanGiaTriDauVaoHopLe();
        printf("Tổng các số chẵn giữa từ 1 đến n sử dụng vòng lặp for: %d\n", tinhTongBangVongLapFor(n));
        printf("Tổng các số chẵn giữa từ 1 đến n sử dụng vòng lặp while: %d\n", tinhTongBangVongLapWhile(n));
        printf("Tổng các số chẵn giữa từ 1 đến n sử dụng vòng lặp do-while: %d\n", tinhTongBangVongLapDoWhile(n));
        return 0;
    }
    int nhanGiaTriDauVaoHopLe() {
        int n;
        do {
            printf("Nhập một số bất kỳ: ");
            if (scanf("%d", &n) != 1) {
                while(getchar() != '\n'); // getchar() dùng để xóa bộ đệm đầu vào
                n = -1; // Gán n giá trị ko hợp lệ
            }
        } while (n <= 0);
        return n;
    }

    int tinhTongBangVongLapFor(int n) {
        int sum = 0;
        for (int i =2; i <= n; i+=2) {
            sum += i;
        }
        return sum;
    }

    int tinhTongBangVongLapWhile(int n) {
        int sum = 0;
        int i = 2;
        while (i <= n) {
            sum += i;
            i += 2;
        }
        return sum;
    }

    int tinhTongBangVongLapDoWhile(int n) {
        int sum = 0;
        int i = 2;
        if (n >= 2) {
            do {
                sum += i;
                i += 2;
            } while(i <= n);
        }
        return sum;
    }