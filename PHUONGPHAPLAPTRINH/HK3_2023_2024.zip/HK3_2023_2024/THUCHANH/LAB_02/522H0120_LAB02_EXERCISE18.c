#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

//Function to convert decimal to binary
void decimalToBinary(int num) {
    int binary[32];
    int index = 0;
    //Special case for 0
    if (num == 0) {
        printf("0");
        return;
    }
    //Convert decimal to binary
    while (num > 0) {
        binary[index] = num % 2;
        num = num / 2;
        index++;
    }
    //Print binary array in reverse order
    for (int i = index - 1; i >= 0; i--) {
        printf("%d", binary[i]);
    }
}

int main() {
    int num;
    printf("Enter a decimal number: ");
    scanf("%d", &num);

    printf("Binary representation: ");
    decimalToBinary(num);
    printf("\n");
    return 0;
}
