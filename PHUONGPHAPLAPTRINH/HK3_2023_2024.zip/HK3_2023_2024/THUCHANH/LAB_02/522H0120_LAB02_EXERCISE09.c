#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int swapFirstAndLastDigits(int num) {
    if (num < 10 && num > -10) {
        return num;
    }
    int isNegative = (num < 0) ? 1 : 0;
    if (isNegative) {
        num = -num;
    }

    int digits = (int)log10(num);

    int firstDigit = num / (int)pow(10, digits);
    int lastDigit = num % 10;

    int swappedNum = lastDigit * (int)pow(10, digits); // Last digit to the first position
    swappedNum += num % (int)pow(10, digits);         // Add the middle part
    swappedNum -= lastDigit;                          // Remove the last digit
    swappedNum += firstDigit;                         // Add the first digit to the last position

    if (isNegative) {
        swappedNum = -swappedNum;
    }
    return swappedNum;
}

int main() {
    int num;
    printf("Enter any positive integer number: ");
    scanf("%d", &num);
    int result = swapFirstAndLastDigits(num);
    printf("Number after swapping first and last digits: %d\n", result);
    return 0;
}
