#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
//Check if a number is prime or not
bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i <= num / 2; i++) {
        if (num % i == 0) return false;
    }
    return true;
}
//Validate the input
bool isValidInput(int num) {
    return num > 0;
}

int main() {
    int n;
    bool valid;
    //Input validation loop using do-while
    do {
        printf("Enter a positive integer greater than 1: ");
        valid = scanf("%d", &n) == 1 && isValidInput(n);

        if (!valid) {
            printf("Invalid input. Please enter a positive integer greater than 1.\n");
            // Clear the input buffer
            while (getchar() != '\n');
        }
    } while (!valid);

    printf("Prime numbers between 1 and %d are:\n", n);
    // Using for loop
    printf("Using for loop:\n");
    for (int i = 2; i <= n; i++) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
    // Using while loop
    printf("Using while loop:\n");
    int i = 2;
    while (i <= n) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
        i++;
    }
    printf("\n");
    // Using do-while loop
    printf("Using do-while loop:\n");
    i = 2;
    do {
        if (isPrime(i)) {
            printf("%d ", i);
        }
        i++;
    } while (i <= n);
    printf("\n");
    return 0;
}