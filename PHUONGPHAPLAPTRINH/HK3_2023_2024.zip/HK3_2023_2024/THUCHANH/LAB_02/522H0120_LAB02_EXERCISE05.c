#include <stdio.h>

int main() {
    int num, chuSoDauTien, chuSoCuoiCung;
    printf("Nhập một số nguyên dương bất kỳ: ");
    scanf("%d", &num);
    chuSoCuoiCung = num % 10;
    chuSoDauTien = num;
    while (chuSoDauTien >= 10) {
        chuSoDauTien = chuSoDauTien / 10;
    }
    printf("Chữ số đầu tiên của số được nhập vào: %d\n", chuSoDauTien);
    printf("Chữ số cuối cùng của số được nhập vào: %d\n", chuSoCuoiCung);
    return 0;
}
