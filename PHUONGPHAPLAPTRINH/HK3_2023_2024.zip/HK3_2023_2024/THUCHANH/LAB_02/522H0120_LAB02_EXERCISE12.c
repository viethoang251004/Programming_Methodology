#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

bool isPrime(int num) {
    if (num <= 1) {
        return false;
    }
    for (int i = 2; i <= num / 2; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

bool isValidInput(int num) {
    return num > 0;
}

int main() {
    int num;
    bool valid;
    do {
        printf("Enter any positive integer number: ");
        valid = scanf("%d", &num) == 1 && isValidInput(num);

        if (!valid) {
            printf("Invalid input. Please enter a positive integer.\n");
            // Clear the input buffer
            while (getchar() != '\n');
        }
    } while (!valid);

    if (isPrime(num)) {
        printf("%d is a prime number.\n", num);
    } else {
        printf("%d is not a prime number.\n", num);
    }
    return 0;
}