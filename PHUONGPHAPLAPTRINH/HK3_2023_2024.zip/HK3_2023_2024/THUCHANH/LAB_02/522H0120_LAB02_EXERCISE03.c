#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int nhanGiaTriDauVaoHopLe();

int main() {
    int n;
    n = nhanGiaTriDauVaoHopLe();
    printf("Bảng cửu chương cho %d:\n", n);
    for (int i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", n, i, n * i);
    }
    return 0;
}

int nhanGiaTriDauVaoHopLe() {
    int n;
    printf("Nhập vào một số nguyên bất kỳ: ");
    while (scanf("%d", &n) != 1) {
        while (getchar() != '\n'); // Clear the input buffer
        printf("Đầu vào không hợp lệ. Vui lòng nhập một số nguyên: ");
    }
    return n;
}
