#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Ex1
struct Employee
{
    char id[100];
    char name[100];
    char sex[10];
    int birthyear;
    char phonenumber[15];
    int salary;
} Employee;
int main()
{
    return 0;
}