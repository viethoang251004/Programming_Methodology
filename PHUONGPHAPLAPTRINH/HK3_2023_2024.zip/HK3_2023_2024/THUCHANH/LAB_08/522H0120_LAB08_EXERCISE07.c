#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Ex1
struct Employee
{
    char id[100];
    char name[100];
    char sex[10];
    int birthyear;
    char phonenumber[15];
    int salary;
} Employee;

// Ex7
int compareBySalary(const void *a, const void *b);

// Ex3
void inTatCaThongTinNhanVien(struct Employee employees[], int size);

int main()
{
    // Ex2
    struct Employee employees[10];
    // Them thong tin cho nhan vien
    employees[0] = (struct Employee){
        .id = "522H0122",
        .name = "Hùng Anh",
        .sex = "Male",
        .birthyear = 2000,
        .phonenumber = "0123456789",
        .salary = 5000000};
    employees[1] = (struct Employee){
        .id = "522H0120",
        .name = "Viet Hoang",
        .sex = "Male",
        .birthyear = 2004,
        .phonenumber = "0987654321",
        .salary = 60000000};
    employees[2] = (struct Employee){
        .id = "522H0129",
        .name = "Tram Anh",
        .sex = "Female",
        .birthyear = 1999,
        .phonenumber = "0123456780",
        .salary = 4000000};
    employees[3] = (struct Employee){
        .id = "522H0229",
        .name = "Anh Quan",
        .sex = "Male",
        .birthyear = 2001,
        .phonenumber = "0987654320",
        .salary = 5500000};
    employees[4] = (struct Employee){
        .id = "522H0128",
        .name = "Huyen Thanh",
        .sex = "Female",
        .birthyear = 2002,
        .phonenumber = "0123456781",
        .salary = 4500000};
    employees[5] = (struct Employee){
        .id = "522H0123",
        .name = "Minh Nguyen",
        .sex = "Male",
        .birthyear = 2003,
        .phonenumber = "0987654322",
        .salary = 6500000};
    employees[6] = (struct Employee){
        .id = "522H0125",
        .name = "Hai Thanh",
        .sex = "Female",
        .birthyear = 2005,
        .phonenumber = "0123456782",
        .salary = 5000000};
    employees[7] = (struct Employee){
        .id = "522H0127",
        .name = "Thai Nguyen",
        .sex = "Male",
        .birthyear = 2006,
        .phonenumber = "0987654323",
        .salary = 6000000};
    employees[8] = (struct Employee){
        .id = "522H0124",
        .name = "Van Hanh",
        .sex = "Female",
        .birthyear = 2007,
        .phonenumber = "0123456783",
        .salary = 5500000};
    employees[9] = (struct Employee){
        .id = "522H0126",
        .name = "Tuan Thanh",
        .sex = "Male",
        .birthyear = 2008,
        .phonenumber = "0987654324",
        .salary = 6500000};

    // Sort employees by salary
    qsort(employees, 10, sizeof(struct Employee), compareBySalary);

    inTatCaThongTinNhanVien(employees, 10);
    return 0;
}

// Ex7
int compareBySalary(const void *a, const void *b) {
    struct Employee *empA = (struct Employee *)a;
    struct Employee *empB = (struct Employee *)b;
    return empA->salary - empB->salary;
}

void inTatCaThongTinNhanVien(struct Employee employees[], int size) {
    // Ex3
    for (int i = 0; i < size; i++) {
        printf("Employee %d:\n", i + 1);
        printf("ID: %s\n", employees[i].id);
        printf("Name: %s\n", employees[i].name);
        printf("Sex: %s\n", employees[i].sex);
        printf("Birth Year: %d\n", employees[i].birthyear);
        printf("Phone Number: %s\n", employees[i].phonenumber);
        printf("Salary: %d\n\n", employees[i].salary);
    }
}