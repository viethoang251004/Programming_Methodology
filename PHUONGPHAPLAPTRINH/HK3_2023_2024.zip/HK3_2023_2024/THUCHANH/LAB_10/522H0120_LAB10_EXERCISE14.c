#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int countDuplicate(int a[], int n, int k) {
    int count = 0;
    //Duyệt qua từng phần tử của mảng
    for (int i = 0; i < n; i++) {
        if (a[i] == k) {
            count++;  //Tăng biến đếm nếu tìm thấy giá trị k
        }
    }
    return count;  //Trả về số lần xuất hiện của k
}

int main() {
    int n, k;
    //Nhập kích thước của mảng
    printf("Nhập số phần tử của mảng: ");
    scanf("%d", &n);

    int a[n];
    printf("Nhập các phần tử của mảng:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    //nhập giá trị k cần đếm
    printf("Nhập giá trị k: ");
    scanf("%d", &k);
    // gọi hàm countDuplicate và in kết quả
    int soLanXuatHien = countDuplicate(a, n, k);
    printf("Giá trị %d xuất hiện %d lần trong mảng.\n", k, soLanXuatHien);

    return 0;
}
