#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int main() {
    int n, gio, phut, giay;
    //nhập số giây
    printf("Nhập vào số giây: ");
    scanf("%d", &n);
    //tính số giờ
    gio = n / 3600;
    //tính số phút còn lại sau khi đã trừ giờ
    phut = (n % 3600) / 60;
    //tính số giây còn lại sau khi đã trừ giờ và phút
    giay = n % 60;

    printf("%d giây tương đương với: %d giờ, %d phút, %d giây\n", n, gio, phut, giay);
    return 0;
}
