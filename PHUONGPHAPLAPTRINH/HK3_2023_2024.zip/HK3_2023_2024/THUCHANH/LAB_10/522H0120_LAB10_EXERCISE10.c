#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int f(int x) {
    if (x == 0) {
        return 4;
    } else if (x == 1) {
        return 7;
    } else if (x >= 1) {
        return 4 * f(x) - f(x - 1);
    }
}

int main() {
    int x;
    printf("Nhập x: ");
    scanf("%d", &x);
    int ketQua = f(x);
    printf("f(%d) = %d\n", x, ketQua);
    return 0;
}
