#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

// Hàm đệ quy để tính giai thừa
unsigned long long tinhGiaiThua(int n) {
    if (n <= 1) {
        return 1;
    } else {
        return n * tinhGiaiThua(n - 1);
    }
}

int main() {
    int n;

    // Nhập số nguyên không âm
    printf("Nhập một số nguyên không âm: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Số nhập vào phải là số nguyên không âm.\n");
    } else {
        unsigned long long ketQua = tinhGiaiThua(n);
        printf("Giai thừa của %d là: %llu\n", n, ketQua);
    }

    return 0;
}
