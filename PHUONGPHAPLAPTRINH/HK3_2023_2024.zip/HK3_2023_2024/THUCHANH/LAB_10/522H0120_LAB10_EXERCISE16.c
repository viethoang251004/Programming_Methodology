#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int sumEven(int a[], int n) {
    int sum = 0;
    //Duyệt qua từng phần tử của mảng
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0) { //Kiểm tra nếu phần tử là số chẵn
            sum += a[i]; // Cộng vào tổng nếu phần tử là số chẵn
        }
    }
    return sum; //Trả về tổng các số chẵn
}

int main() {
    int n;
    //Nhập kích thước của mảng
    printf("Nhập số phần tử của mảng: ");
    scanf("%d", &n);

    int a[n];
    printf("Nhập các phần tử của mảng:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    // Gọi hàm sumEven và in kết quả
    int tongSoChan = sumEven(a, n);
    printf("Tổng các số chẵn trong mảng là: %d\n", tongSoChan);

    return 0;
}
