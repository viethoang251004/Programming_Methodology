#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int tim_so_lon_nhat(int arr[], int n) {
    //Giả định số lớn nhất là phần tử đầu tiên
    int max_val = arr[0];
    //Duyệt qua từng phần tử trong mảng
    for (int i = 1; i < n; i++) {
        if (arr[i] > max_val) {
            max_val = arr[i];  //Cập nhật số lớn nhất nếu tìm thấy số lớn hơn
        }
    }

    return max_val;
}

int main() {
    int arr[] = {1, 5, 3, 9, 2};
    int n = sizeof(arr) / sizeof(arr[0]);

    int max_val = tim_so_lon_nhat(arr, n);
    printf("So lon nhat trong mang la: %d\n", max_val);
    return 0;
}
