#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

//Hàm kiểm tra chuỗi đối xứng
int isPalindrome(char str[]) {
    int length = strlen(str);
    int left = 0;
    int right = length - 1;
    //So sánh các ký tự từ hai đầu chuỗi
    while (left < right) {
        if (str[left] != str[right]) {
            return 0; //Không phải chuỗi đối xứng
        }
        left++;
        right--;
    }
    return 1; //Là chuỗi đối xứng
}

int main() {
    char str[100];
    // nhập chuỗi
    printf("Nhập vào một chuỗi: ");
    gets(str);
    // kiểm tra và in kết quả
    if (isPalindrome(str)) {
        printf("Chuỗi là chuỗi đối xứng.\n");
    } else {
        printf("Chuỗi không phải là chuỗi đối xứng.\n");
    }
    return 0;
}
