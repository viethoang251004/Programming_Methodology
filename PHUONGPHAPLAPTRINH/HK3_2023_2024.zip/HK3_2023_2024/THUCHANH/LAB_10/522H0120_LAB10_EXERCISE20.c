#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

//Hàm tính giai thừa của một số nguyên dương
long long factorial(int n) {
    long long result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

//tính tổng biểu thức a
int tinh_a(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += 2 * i + 1;
    }
    return sum;
}

//tính tổng biểu thức b
long long tinh_b(int n) {
    long long sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += factorial(i) + 1;
    }
    return sum;
}

//tính tổng biểu thức c
double tinh_c(int n) {
    double sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += (double)(2 * i + 1) / i;
    }
    return sum;
}

int main() {
    int n;

    printf("Nhap gia tri cua n: ");
    scanf("%d", &n);
    // Tính và in kết quả các biểu thức
    int result_a = tinh_a(n);
    long long result_b = tinh_b(n);
    double result_c = tinh_c(n);

    printf("Gia tri bieu thuc a: %d\n", result_a);
    printf("Gia tri bieu thuc b: %lld\n", result_b);
    printf("Gia tri bieu thuc c: %.2lf\n", result_c);
    return 0;
}
