#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int sumOdd(int a[], int n) {
    int sum = 0;

    // Duyệt qua từng phần tử của mảng
    for (int i = 0; i < n; i++) {
        if (a[i] % 2 != 0) { // Kiểm tra nếu phần tử là số lẻ
            sum += a[i]; //Cộng vào tổng nếu phần tử là số lẻ
        }
    }

    return sum; // Trả về tổng các số lẻ
}

int main() {
    int n;
    //Nhập kích thước của mảng
    printf("Nhập số phần tử của mảng: ");
    scanf("%d", &n);

    int a[n];
    printf("Nhập các phần tử của mảng:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    //Gọi hàm sumOdd và in kết quả
    int tongSoLe = sumOdd(a, n);
    printf("Tổng các số lẻ trong mảng là: %d\n", tongSoLe);

    return 0;
}
