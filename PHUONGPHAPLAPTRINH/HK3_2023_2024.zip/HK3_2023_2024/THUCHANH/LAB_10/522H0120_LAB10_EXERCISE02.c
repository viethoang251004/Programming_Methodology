#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int main() {
    double circumference, radius, area;
    const double PI = 3.14159265358979323846;
    //Nhập chu vi của hình tròn
    printf("Nhập chu vi của hình tròn: ");
    scanf("%lf", &circumference);
    //Tính bán kính từ chu vi
    radius = circumference / (2 * PI);
    // Tính diện tích hình tròn
    area = PI * pow(radius, 2);

    printf("Diện tích của hình tròn là: %.2lf\n", area);
    return 0;
}
