#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

typedef struct {
    char maSo[10];
    char hoTen[50];
    float diemPPLT;   //Điểm Phương pháp lập trình
    float diemDSTL;   //Điểm Đại số tuyến tính
    float diemTCTH;   //Điểm Toán cho tin học
    float diemTB;     //Điểm trung bình tích lũy
    char xepLoai;     // Xếp loại: 'X' - Xuất sắc, 'K' - Khá, 'T' - Trung bình, 'Y' - Yếu
} SinhVien;

void tinhDiemTB(SinhVien *sv) {
    sv->diemTB = (sv->diemPPLT + sv->diemDSTL + sv->diemTCTH) / 3.0;
}

void xepLoaiSV(SinhVien *sv) {
    if (sv->diemTB >= 8.5) {
        sv->xepLoai = 'X';  // Xuất sắc
    } else if (sv->diemTB >= 7.0) {
        sv->xepLoai = 'K';  // Khá
    } else if (sv->diemTB >= 5.0) {
        sv->xepLoai = 'T';  // Trung bình
    } else {
        sv->xepLoai = 'Y';  // Yếu
    }
}

SinhVien* timSinhVien(SinhVien svArray[], int soLuong, const char* maSo) {
    for (int i = 0; i < soLuong; i++) {
        if (strcmp(svArray[i].maSo, maSo) == 0) {
            return &svArray[i];
        }
    }
    return NULL; // Không tìm thấy
}

SinhVien* timSVDiemTBNhoNhat(SinhVien svArray[], int soLuong) {
    if (soLuong == 0) return NULL;

    SinhVien* svMin = &svArray[0];
    for (int i = 1; i < soLuong; i++) {
        if (svArray[i].diemTB < svMin->diemTB) {
            svMin = &svArray[i];
        }
    }
    return svMin;
}

int demSVKhaTroLen(SinhVien svArray[], int soLuong) {
    int dem = 0;
    for (int i = 0; i < soLuong; i++) {
        if (svArray[i].xepLoai == 'X' || svArray[i].xepLoai == 'K') {
            dem++;
        }
    }
    return dem;
}

int main() {
    int soLuongSV;
    
    printf("Nhập số lượng sinh viên: ");
    scanf("%d", &soLuongSV);

    SinhVien svArray[soLuongSV];
    //Nhập thông tin sinh viên
    for (int i = 0; i < soLuongSV; i++) {
        printf("\nNhập thông tin sinh viên thứ %d:\n", i + 1);
        printf("Mã số sinh viên: ");
        scanf("%s", svArray[i].maSo);
        printf("Họ tên: ");
        getchar();  // Để bỏ qua ký tự newline
        gets(svArray[i].hoTen);
        printf("Điểm Phương pháp lập trình: ");
        scanf("%f", &svArray[i].diemPPLT);
        printf("Điểm Đại số tuyến tính: ");
        scanf("%f", &svArray[i].diemDSTL);
        printf("Điểm Toán cho tin học: ");
        scanf("%f", &svArray[i].diemTCTH);
        
        //Tính điểm trung bình và xếp loại
        tinhDiemTB(&svArray[i]);
        xepLoaiSV(&svArray[i]);
    }
    // a. Tìm sinh viên thông qua mã số sinh viên
    char maSoTimKiem[10];
    printf("\nNhập mã số sinh viên cần tìm: ");
    scanf("%s", maSoTimKiem);
    SinhVien* svTimThay = timSinhVien(svArray, soLuongSV, maSoTimKiem);
    if (svTimThay != NULL) {
        printf("Sinh viên tìm thấy: %s, Điểm trung bình: %.2f, Xếp loại: %c\n", svTimThay->hoTen, svTimThay->diemTB, svTimThay->xepLoai);
    } else {
        printf("Không tìm thấy sinh viên có mã số %s\n", maSoTimKiem);
    }
    // d. Tìm sinh viên có điểm trung bình thấp nhất
    SinhVien* svThapNhat = timSVDiemTBNhoNhat(svArray, soLuongSV);
    printf("Sinh viên có điểm trung bình thấp nhất là: %s, Điểm trung bình: %.2f\n", svThapNhat->hoTen, svThapNhat->diemTB);
    // e. Thống kê số sinh viên có học lực khá trở lên
    int soSVKhaTroLen = demSVKhaTroLen(svArray, soLuongSV);
    printf("Số lượng sinh viên có học lực khá trở lên: %d\n", soSVKhaTroLen);

    return 0;
}
