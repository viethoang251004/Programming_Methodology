#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int search(int a[], int n, int k) {
    //Duyệt qua từng phần tử của mảng
    for (int i = 0; i < n; i++) {
        if (a[i] == k) {
            return i;  //Trả về vị trí đầu tiên tìm thấy k
        }
    }
    return -1;  //Nếu không tìm thấy k, trả về -1
}

int main() {
    int n, k;
    //Nhập kích thước của mảng
    printf("Nhập số phần tử của mảng: ");
    scanf("%d", &n);

    int a[n];
    printf("Nhập các phần tử của mảng:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    //Nhập giá trị k cần tìm kiếm
    printf("Nhập giá trị k: ");
    scanf("%d", &k);
    //Gọi hàm search và in kết quả
    int viTri = search(a, n, k);

    if (viTri != -1) {
        printf("Giá trị %d được tìm thấy tại vị trí %d trong mảng.\n", k, viTri);
    } else {
        printf("Giá trị %d không tồn tại trong mảng.\n", k);
    }

    return 0;
}
