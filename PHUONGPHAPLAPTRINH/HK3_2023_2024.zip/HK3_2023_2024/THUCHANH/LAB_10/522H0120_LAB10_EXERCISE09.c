#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int f(int x) {
    if (x == 0) {
        return 3;
    } else if (x == 1) {
        return 5;
    } else if (x >= 1) {
        return f(x - 1) + 2 * f(x - 2);
    }
}

int main() {
    int x;
    printf("Nhập x: ");
    scanf("%d", &x);
    int ketQua = f(x);
    printf("f(%d) = %d\n", x, ketQua);
    return 0;
}
