#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

// Hàm đệ quy để chuyển đổi số nguyên dương thành nhị phân
void convertToBinary(int n) {
    if (n == 0) {
        return;
    }
    
    convertToBinary(n / 2); //Gọi đệ quy với phần nguyên của n/2
    printf("%d", n % 2);     //In ra phần dư của n chia cho 2 (0 hoặc 1)
}

int main() {
    int n;
    //Nhập số nguyên dương
    printf("Nhập một số nguyên dương: ");
    scanf("%d", &n);
    //Kiểm tra nếu số nhập vào là 0 thì in trực tiếp 0
    if (n == 0) {
        printf("Số nhị phân: 0\n");
    } else {
        printf("Số nhị phân: ");
        convertToBinary(n); //Gọi hàm đệ quy để chuyển đổi
        printf("\n");
    }
    return 0;
}
