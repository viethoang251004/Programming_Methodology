#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int tim_so_nho_nhat(int arr[], int n) {
    //Giả định số nhỏ nhất là phần tử đầu tiên
    int min_val = arr[0];
    //duyệt qua từng phần tử trong mảng
    for (int i = 1; i < n; i++) {
        if (arr[i] < min_val) {
            min_val = arr[i]; //cập nhật số nhỏ nhất nếu tìm thấy số nhỏ hơn
        }
    }

    return min_val;
}

int main() {
    int arr[] = {1, 5, 3, -9, 2};
    int n = sizeof(arr) / sizeof(arr[0]);

    int min_val = tim_so_nho_nhat(arr, n);
    printf("So nho nhat trong mang la: %d\n", min_val);
    return 0;
}
