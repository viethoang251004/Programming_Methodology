#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

//kiểm tra năm nhuận
bool isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}
//kiểm tra ngày hợp lệ
bool isValidDate(int day, int month, int year) {
    //kiểm tra tháng hợp lệ
    if (month < 1 || month > 12) {
        return false;
    }
    //kiểm tra ngày hợp lệ theo tháng
    switch (month) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            if (day < 1 || day > 31) return false;
            break;
        case 4: case 6: case 9: case 11:
            if (day < 1 || day > 30) return false;
            break;
        case 2:
            if (isLeapYear(year)) {
                if (day < 1 || day > 29) return false;
            } else {
                if (day < 1 || day > 28) return false;
            }
            break;
        default:
            return false;
    }
    //kiểm tra năm hợp lệ
    if (year < 1) {
        return false;
    }

    return true;
}

int main() {
    int day, month, year;
    //nhập thông tin ngày, tháng, năm
    printf("Nhập ngày: ");
    scanf("%d", &day);
    printf("Nhập tháng: ");
    scanf("%d", &month);
    printf("Nhập năm: ");
    scanf("%d", &year);
    //kiểm tra thông tin ngày tháng năm hợp lệ
    if (isValidDate(day, month, year)) {
        printf("Ngày %d/%d/%d là ngày hợp lệ.\n", day, month, year);
    } else {
        printf("Ngày %d/%d/%d không hợp lệ.\n", day, month, year);
    }

    return 0;
}
