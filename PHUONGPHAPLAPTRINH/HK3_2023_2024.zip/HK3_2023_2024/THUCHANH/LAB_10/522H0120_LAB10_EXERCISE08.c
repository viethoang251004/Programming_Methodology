#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int f(int x) {
    if (x == 0) {
        return 1;
    } else if (x == 1) {
        return 2;
    } else if (x >= 1) {
        return 2 * f(x - 1) + 3 * f(x - 2);
    }
}

int main() {
    int x;
    printf("Nhập x: ");
    scanf("%d", &x);
    int ketQua = f(x);
    printf("f(%d) = %d\n", x, ketQua);
    return 0;
}
