#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

int main() {
    double xA, yA, xB, yB, distance;
    printf("Enter coordinates of point A (xA, yA): ");
    scanf("%lf %lf", &xA, &yA);
    printf("Enter coordinates of point B (xB, yB): ");
    scanf("%lf %lf", &xB, &yB);
    distance = sqrt(pow(xA - xB, 2) + pow(yA - yB, 2));
    printf("The distance between A and B is: %.2lf\n", distance);
    return 0;
}
