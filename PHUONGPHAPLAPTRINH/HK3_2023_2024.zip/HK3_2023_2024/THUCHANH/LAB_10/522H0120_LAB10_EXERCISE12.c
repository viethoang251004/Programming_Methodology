#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

void selectionSort(int arr[], int n) {
    int i, j, minIndex, temp;
    // Duyệt qua từng phần tử của mảng
    for (i = 0; i < n-1; i++) {
        // Giả định phần tử hiện tại là nhỏ nhất
        minIndex = i;
        // Tìm chỉ số của phần tử nhỏ nhất trong đoạn còn lại
        for (j = i+1; j < n; j++) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        // Hoán đổi phần tử nhỏ nhất với phần tử hiện tại
        temp = arr[minIndex];
        arr[minIndex] = arr[i];
        arr[i] = temp;
    }
}

void bubbleSort(int arr[], int n) {
    int i, j, temp;

    // Lặp lại quá trình sắp xếp nhiều lần
    for (i = 0; i < n-1; i++) {
        // Đẩy phần tử lớn nhất về cuối mảng
        for (j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                // Hoán đổi hai phần tử kề nhau nếu không đúng thứ tự
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main() {
    int n;

    printf("Nhập số phần tử của mảng: ");
    scanf("%d", &n);

    int arr[n];
    printf("Nhập các phần tử của mảng:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Sắp xếp mảng sử dụng Selection Sort
    selectionSort(arr, n);
    printf("Mảng sau khi sắp xếp chọn trực tiếp:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // Sắp xếp mảng sử dụng Bubble Sort
    bubbleSort(arr, n);
    printf("Mảng sau khi sắp xếp nổi bọt:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    return 0;
}
