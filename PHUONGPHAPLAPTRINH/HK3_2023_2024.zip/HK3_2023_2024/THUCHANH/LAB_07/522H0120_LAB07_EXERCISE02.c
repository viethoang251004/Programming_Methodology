#include <stdio.h>

int binarySearch(int arr[], int size, int target) {
    int left = 0;
    int right = size - 1;
    while (left <= right) {
        int middle = left + (right - left) / 2;
        // Check if target is present at mid
        if (arr[middle] == target) {
            return middle;
        }
        // If target is greater, ignore the left half
        if (arr[middle] < target) {
            left = middle + 1;
        }
        // If target is smaller, ignore the right half
        else {
            right = middle - 1;
        }
    }
    // Target is not present in array
    return -1;
}

int main() {
    int arr[] = {3, 5, 7, 9, 11};
    int size = sizeof(arr) / sizeof(arr[0]);
    int target = 3;
    int result = binarySearch(arr, size, target);
    if (result != -1) {
        printf("Element found at index %d\n", result);
    } else {
        printf("Element not found in the array\n");
    }
    return 0;
}
