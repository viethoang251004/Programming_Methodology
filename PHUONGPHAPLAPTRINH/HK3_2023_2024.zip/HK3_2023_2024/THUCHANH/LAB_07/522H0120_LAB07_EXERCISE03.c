#include <stdio.h>

void selection_sort_desc(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        //Find the maximum element in the remaining unsorted array
        int max_idx = i;
        for (int j = i + 1; j < size; j++) {
            if (arr[j] > arr[max_idx]) {
                max_idx = j;
            }
        }
        //Swap the found maximum element with the first element
        int temp = arr[max_idx];
        arr[max_idx] = arr[i];
        arr[i] = temp;
    }
}

void print_array(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int arr[] = {3, 5, 7, 9, 11};
    int size = sizeof(arr) / sizeof(arr[0]);
    printf("Original array: ");
    print_array(arr, size);
    selection_sort_desc(arr, size);
    printf("Sorted array in descending order: ");
    print_array(arr, size);
    return 0;
}
