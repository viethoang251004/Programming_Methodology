#include <stdio.h>

void bubble_sort_desc(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] < arr[j + 1]) {
                // Swap arr[j] and arr[j + 1]
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void print_array(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int arr[] = {3, 5, 7, 9, 11};
    int size = sizeof(arr) / sizeof(arr[0]);
    printf("Original array: ");
    print_array(arr, size);
    bubble_sort_desc(arr, size);
    printf("Sorted array in descending order: ");
    print_array(arr, size);
    return 0;
}


// #include <stdio.h>

// void bubble_sort_desc();

// void print_array(int arr[], int size);

// int main() {
//     int arr[100] = {1, 3, 5, 6, 7, 8, 9, 8};
//     int size = sizeof(arr) / sizeof(arr[0]);
//     printf("Original array: ");

// }

// void print_array(int arr[], int size) {
//     for (int i = 0; i < size; i++) {
//         printf("%d ", arr[i]);
//     }
//     printf("\n");
// }

// void bubble_sort_desc(int arr[], int size) {
//     int size = sizeof(arr) / sizeof(arr[0]);
//     for (int i = 0; i < size; i++) {
//         for (int j = 0; j < size; j++) {
//             if (arr[j] == arr[i])
//         }
//     }
// }