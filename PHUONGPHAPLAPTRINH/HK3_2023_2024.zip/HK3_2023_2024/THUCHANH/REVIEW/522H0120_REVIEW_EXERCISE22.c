#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

void separateEvenOdd(int arr[], int size, int evenArr[], int *evenSize, int oddArr[], int *oddSize) {
    for (int i = 0; i < size; ++i) {
        if (arr[i] % 2 == 0) {
            evenArr[(*evenSize)++] = arr[i]; // Add even element to evenArr
        } else {
            oddArr[(*oddSize)++] = arr[i]; // Add odd element to oddArr
        }
    }
}

int main() {
    int myArray[] = {1, 2, 3, 4, 5, 6, 7, 8}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    int evenElements[100]; // New array for even elements
    int evenSize = 0;
    int oddElements[100]; // New array for odd elements
    int oddSize = 0;

    separateEvenOdd(myArray, arraySize, evenElements, &evenSize, oddElements, &oddSize);

    printf("Even elements: ");
    for (int i = 0; i < evenSize; ++i) {
        printf("%d ", evenElements[i]);
    }
    printf("\n");

    printf("Odd elements: ");
    for (int i = 0; i < oddSize; ++i) {
        printf("%d ", oddElements[i]);
    }
    printf("\n");

    return 0;
}
