#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

int sum_array(int arr[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return sum;
}

int main() {
    int array[] = {3, 5, 7, 2, 8, -1, 4, 10, 12};
    int n = sizeof(array) / sizeof(array[0]);
    int total_sum = sum_array(array, n);

    printf("The sum of all numbers in the array is: %d\n", total_sum);
    return 0;
}
