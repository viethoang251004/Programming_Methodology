#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

void removeDuplicates(int arr[], int *size) {
    int freqMap[100] = {0}; // Assuming array elements are within [0, 99]
    int uniqueArray[100]; // Create a new array for unique elements
    int uniqueSize = 0;

    for (int i = 0; i < *size; ++i) {
        if (freqMap[arr[i]] == 0) {
            freqMap[arr[i]] = 1;
            uniqueArray[uniqueSize++] = arr[i];
        }
    }
    // Copy unique elements back to the original array
    for (int i = 0; i < uniqueSize; ++i) {
        arr[i] = uniqueArray[i];
    }
    *size = uniqueSize; // Update the array size
}

int main() {
    int myArray[] = {1, 2, 3, 2, 4, 3, 5, 5, 9, 8, 9}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    printf("Original array: ");
    for (int i = 0; i < arraySize; ++i) {
        printf("%d ", myArray[i]);
    }
    printf("\n");
    removeDuplicates(myArray, &arraySize);
    printf("Array after removing duplicates: ");
    for (int i = 0; i < arraySize; ++i) {
        printf("%d ", myArray[i]);
    }
    printf("\n");
    return 0;
}
