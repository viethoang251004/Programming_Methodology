#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

int find_minimum(int arr[], int n) {
    if (n <= 0) {
        printf("Array is empty\n");
        return -1; // Return -1 or any other value to indicate an error
    }

    int min_num = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] < min_num) {
            min_num = arr[i];
        }
    }
    return min_num;
}

int main() {
    int array[] = {3, 5, 7, 2, 8, 1, 4, 10, 12};
    int n = sizeof(array) / sizeof(array[0]);
    int min = find_minimum(array, n);

    if (min != -1) {
        printf("The minimum number in the array is: %d\n", min);
    }
    return 0;
}
