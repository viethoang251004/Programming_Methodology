#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

//  Count the number of digits in a number
int countDigits(int num) {
    int count = 0;
    while (num != 0) {
        num /= 10;
        count++;
    }
    return count;
}

// Check if a number is an Armstrong number or not
bool isArmstrong(int num) {
    int sum = 0, original = num, remainder, n;
    n = countDigits(num);
    // Calculate the sum of the powers of each digit
    while (num != 0) {
        remainder = num % 10;
        sum += pow(remainder, n);
        num /= 10;
    }
    // Check if the sum is equal to the original number
    return (sum == original);
}

// Validate input
bool isValidInput(int num) {
    return num > 0;
}

int main() {
    int n;
    bool valid;
    // Input validation loop using do-while
    do {
        printf("Enter a positive integer greater than 0: ");
        valid = scanf("%d", &n) == 1 && isValidInput(n);

        if (!valid) {
            printf("Invalid input. Please enter a positive integer greater than 0.\n");
            // Clear the input buffer
            while (getchar() != '\n');
        }
    } while (!valid);

    printf("Armstrong numbers between 1 and %d are:\n", n);
    // Using for loop
    // printf("Using for loop:\n");
    for (int i = 1; i <= n; i++) {
        if (isArmstrong(i)) {
            printf("%d ", i);
        }
    }
    return 0;
}
