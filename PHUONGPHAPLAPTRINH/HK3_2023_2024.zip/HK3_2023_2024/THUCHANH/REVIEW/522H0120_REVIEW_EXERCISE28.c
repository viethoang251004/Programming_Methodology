#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

bool areMatricesEqual(int A[][100], int B[][100], int m, int n) {
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if (A[i][j] != B[i][j]) {
                return false; // Elements don't match, matrices are not equal
            }
        }
    }
    return true; // All elements match, matrices are equal
}

int main() {
    int m, n;
    printf("Enter the number of rows (m): ");
    scanf("%d", &m);
    printf("Enter the number of columns (n): ");
    scanf("%d", &n);

    int A[100][100], B[100][100];

    printf("Enter elements of matrix A:\n");
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            scanf("%d", &A[i][j]);
        }
    }

    printf("Enter elements of matrix B:\n");
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            scanf("%d", &B[i][j]);
        }
    }

    if (areMatricesEqual(A, B, m, n)) {
        printf("Matrices A and B are equal.\n");
    } else {
        printf("Matrices A and B are not equal.\n");
    }
    return 0;
}
