#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

int find_maximum(int arr[], int n) {
    if (n <= 0) {
        printf("Array is empty\n");
        return -1; // Return -1 or any other value to indicate an error
    }

    int max_num = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max_num) {
            max_num = arr[i];
        }
    }
    return max_num;
}

int main() {
    int array[] = {3, 5, 7, 2, 8, -1, 4, 10, 12};
    int n = sizeof(array) / sizeof(array[0]);
    int max = find_maximum(array, n);

    if (max != -1) {
        printf("The maximum number in the array is: %d\n", max);
    }
    return 0;
}
