#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

int main() {
    int total_days, years, weeks, days;

    printf("Enter the total number of days: ");
    scanf("%d", &total_days);

    // Convert days into years, weeks and remaining days
    years = total_days / 365;  // 1 year = 365 days
    total_days %= 365;         // Remaining days after removing years
    weeks = total_days / 7;    // 1 week = 7 days
    days = total_days % 7;     // Remaining days after removing weeks

    printf("%d years, %d weeks, and %d days\n", years, weeks, days);
    return 0;
}
