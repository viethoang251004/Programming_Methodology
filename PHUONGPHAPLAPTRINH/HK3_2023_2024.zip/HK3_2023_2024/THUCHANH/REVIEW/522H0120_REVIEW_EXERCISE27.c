#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

void multiplyMatrices(int A[][100], int B[][100], int C[][100], int m, int n, int p) {
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < p; ++j) {
            C[i][j] = 0; // Initialize the result matrix element to 0
            for (int k = 0; k < n; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void displayMatrix(int mat[][100], int m, int n) {
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int m, n, p;
    printf("Enter the number of rows (m) for matrix A: ");
    scanf("%d", &m);
    printf("Enter the number of columns (n) for matrix A: ");
    scanf("%d", &n);
    printf("Enter the number of columns (p) for matrix B: ");
    scanf("%d", &p);

    int A[100][100], B[100][100], C[100][100];

    printf("Enter elements of matrix A:\n");
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            scanf("%d", &A[i][j]);
        }
    }

    printf("Enter elements of matrix B:\n");
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < p; ++j) {
            scanf("%d", &B[i][j]);
        }
    }

    multiplyMatrices(A, B, C, m, n, p);

    printf("Resultant matrix C (A * B):\n");
    displayMatrix(C, m, p);
    return 0;
}
