#include <stdio.h>

//Function to calculate sum_a
double sum_a(int n) {
    double sum = 0.0;
    for (int i = 1; i <= n; i++) {
        sum += i / 2.0;
    }
    return sum;
}

//Function to calculate sum_b
int sum_b(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += 2 * i + 1;
    }
    return sum;
}

//Function to calculate sum_c
double sum_c(int n) {
    double sum = 0.0;
    for (int i = 1; i <= n; i++) {
        sum += (i + 1.0) / (i + 2.0);
    }
    return sum;
}

//Function to calculate sum_d
int factorial(int x) {
    if (x == 0) return 1;
    int result = 1;
    for (int i = 1; i <= x; i++) {
        result *= i;
    }
    return result;
}

int sum_d(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += factorial(i) + 1;
    }
    return sum;
}

//Function to calculate prod_e
int prod_e(int n) {
    int product = 1;
    for (int i = 1; i <= n; i++) {
        product *= i;
    }
    return product;
}

//Function to calculate prod_f
int prod_f(int n) {
    int product = 1;
    for (int i = 1; i <= n; i++) {
        product *= factorial(i);
    }
    return product;
}

//Function to calculate prod_g
double prod_g(int n) {
    double product = 1.0;
    for (int i = 1; i <= n; i++) {
        product *= (2.0 * i) / 3.0;
    }
    return product;
}

//Function to calculate prod_h
double prod_h(int n) {
    double product = 1.0;
    for (int i = 1; i <= n; i++) {
        product *= (i - 1.0) / (i + 1.0);
    }
    return product;
}

int main() {
    int n = 5; //Example value, you can change it to test other values
    printf("sum_a(%d) = %lf\n", n, sum_a(n));
    printf("sum_b(%d) = %d\n", n, sum_b(n));
    printf("sum_c(%d) = %lf\n", n, sum_c(n));
    printf("sum_d(%d) = %d\n", n, sum_d(n));
    printf("prod_e(%d) = %d\n", n, prod_e(n));
    printf("prod_f(%d) = %d\n", n, prod_f(n));
    printf("prod_g(%d) = %lf\n", n, prod_g(n));
    printf("prod_h(%d) = %lf\n", n, prod_h(n));
    return 0;
}
