#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

int sumEvenNumbers(int arr[], int size) {
    int sum = 0;
    for (int i = 0; i < size; ++i) {
        if (arr[i] % 2 == 0) {
            sum += arr[i];
        }
    }
    return sum;
}

int main() {
    int myArray[] = {2, 4, 6, 8, 10, 13, 25}; // Example array
    int arraySize = sizeof(myArray) / sizeof(myArray[0]);
    int result = sumEvenNumbers(myArray, arraySize);
    printf("Sum of even numbers: %d\n", result);
    return 0;
}
