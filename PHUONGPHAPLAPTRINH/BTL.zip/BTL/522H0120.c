#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define PI 3.1415926535

int x[10], banh[10] = {0}, ladong[10] = {0}, y[5][6] = {5, 7, 10, 12, 15, 20, 20, 5, 7, 10, 12, 15, 15, 20, 5, 7, 10, 12, 12, 15, 20, 5, 7, 10, 10, 12, 15, 20, 5, 7};
double banhchung(double x, int y)
{
	ladong[0]--;
	banh[0]++;
	return x - pow(y, 2);
}

double banhgiay(double x, int y)
{
	ladong[0]--;
	banh[1]++;
	return x - (pow(y, 2) * PI / 4);
}

double Wind(double nep, int canh, int duongkinh)
{
	while (((nep >= (pow(canh, 2))) && (ladong[0] > 0)) && (canh > 0))
		nep = banhchung(nep, canh);
	while ((nep >= (pow(duongkinh, 2) * PI / 4)) && (ladong[0] > 0) && (duongkinh > 0))
		nep = banhgiay(nep, duongkinh);
	return nep;
}

double Rain(double nep, int canh, int duongkinh)
{
	while ((((nep >= pow(canh, 2)) && (canh > 0)) || ((nep >= (pow(duongkinh, 2) * PI / 4)) && (duongkinh > 0))) && (ladong[0] > 0))
	{
		if ((nep >= pow(canh, 2)) && (canh > 0))
			nep = banhchung(nep, canh);
		if ((nep >= (pow(duongkinh, 2) * PI / 4)) && (duongkinh > 0))
			nep = banhgiay(nep, duongkinh);
	}
	return nep;
}

int tonguoc(int x)
{
	int j, sum = 0;
	for (j = 1; j <= x / 2; j++)
	{
		if (x % j == 0)
			sum += j;
	}
	return sum;
}

int sobanbe(int x)
{
	if ((tonguoc(x) == ladong[0]) && (tonguoc(ladong[0]) == x))
		return 1;
	return 0;
}

double Cloud(int nep, int canh, int duongkinh)
{
	double phandu = nep;
	if (sobanbe(nep) == 1)
		return phandu;
	while ((phandu >= (pow(duongkinh, 2) * PI / 4)) && (duongkinh > 0))
		phandu = banhgiay(phandu, duongkinh);
	while ((phandu >= pow(canh, 2)) && (canh > 0))
		phandu = banhchung(phandu, canh);
	return phandu;
}

double Sun(int nep, int canh, int duongkinh)
{
	int w = canh % 6, z = ladong[0] % 5;
	nep += (nep * y[w][z] / 100.0);
	ladong[0] -= y[w][z];
	if (((duongkinh + canh) % 3) == 0)
		return Rain(nep, canh, duongkinh);
	else if (((duongkinh + canh) % 3) == 1)
		return Wind(nep, canh, duongkinh);
	else
		return Cloud(nep, canh, duongkinh);
}

double Fog(double nep, int canh, int duongkinh)
{
	banh[0] = canh;
	banh[1] = duongkinh;
	return nep;
}

double nepduthaydoitheothoitiet(char thoitiet[])
{
	if (strcmp(thoitiet, "Wind") == 0)
		return Wind(x[0], x[1], x[2]);
	else
	{
		if (strcmp(thoitiet, "Rain") == 0)
			return Rain(x[0], x[1], x[2]);
		else
		{
			if (strcmp(thoitiet, "Sun") == 0)
				return Sun(x[0], x[1], x[2]);
			else
			{
				if (strcmp(thoitiet, "Fog") == 0)
					return Fog(x[0], x[1], x[2]);
				else
					return Cloud(x[0], x[1], x[2]);
			}
		}
	}
}

int main()
{
	double phandu;
	char thoitiet[10];
	FILE *finp, *fout;
	finp = fopen("input.inp", "r");
	if (finp != NULL)
	{
		fscanf(finp, "%d %d %d %d %s", &x[0], &x[1], &x[2], &ladong[0], &thoitiet);
		fclose(finp);
	}
	phandu = nepduthaydoitheothoitiet(thoitiet);
	fout = fopen("output.out", "w");
	if ((x[0] > 1000) || ((ladong[0] < 1) && (ladong[0] > 200)))
		fprintf(fout, "-1 -1 %d", x[0]);
	else
	{
		if (((strcmp(thoitiet, "Cloud") == 0) && (sobanbe(x[0]) == 1)) || ((x[1]) < 0) && (x[2] < 0))
			fprintf(fout, "%.3f", phandu);
		else
		{
			if (x[1] < 0)
				fprintf(fout, "%d %.3f", banh[1], phandu);
			else
			{
				if (x[2] < 0)
					fprintf(fout, "%d %.3f", banh[0], phandu);
				else
					fprintf(fout, "%d %d %.3f", banh[0], banh[1], phandu);
			}
		}
	}
	fclose(fout);
}