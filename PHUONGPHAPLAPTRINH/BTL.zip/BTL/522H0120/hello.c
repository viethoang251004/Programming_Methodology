#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n;
    printf("Hello World!");
    scanf("%d", &n);
    printf("N is: %d", n);
    system("pause");
    return 0;
}