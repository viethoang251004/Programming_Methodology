#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define PI 3.1415926535

int x[10], banh[10] = {0}, ld[10] = {0}, y[5][6] = {5, 7, 10, 12, 15, 20, 20, 5, 7, 10, 12, 15, 15, 20, 5, 7, 10, 12, 12, 15, 20, 5, 7, 10, 10, 12, 15, 20, 5, 7};

double bg(double x, int y)
{
	ld[0] = ld[0] - 1;
	banh[1] = banh[1] + 1;
	return x - (pow(y, 2) * PI / 4);
}

double bc(double x, int y)
{
	ld[0] = ld[0] - 1;
	banh[0] = banh[0] + 1;
	return x - pow(y, 2);
}

double Rain(double nep, int dc, int dg)
{
	while ((((dc > 0) && (nep >= pow(dc, 2))) || ((dg > 0) && (nep >= (pow(dg, 2) * PI / 4)))) && (ld[0] > 0))
	{
		if ((dc > 0) && (nep >= pow(dc, 2)))
			nep = bc(nep, dc);
		if ((dg > 0) && (nep >= (pow(dg, 2) * PI / 4)))
			nep = bg(nep, dg);
	}
	return nep;
}

double Wind(double nep, int dc, int dg)
{
	while (((ld[0] > 0) && (nep >= (pow(dc, 2)))) && (dc > 0))
		nep = bc(nep, dc);
	while ((dg > 0) && (nep >= (pow(dg, 2) * PI / 4)) && (ld[0] > 0))
		nep = bg(nep, dg);
	return nep;
}

double Fog(double nep, int dc, int dg)
{
	banh[0] = dc;
	banh[1] = dg;
	return nep;
}

int tonguoc(int x)
{
	int j, sum = 0;
	for (j = 1; j <= x / 2; j++)
	{
		if (x % j == 0)
			sum = sum + j;
	}
	return sum;
}

int sobanbe(int x)
{
	if ((tonguoc(x) == ld[0]) && (tonguoc(ld[0]) == x))
		return 1;
	return 0;
}

double Cloud(int nep, int dc, int dg)
{
	double phandu = nep;
	if (sobanbe(nep) == 1)
		return phandu;
	while ((dg > 0) && (phandu >= (pow(dg, 2) * PI / 4)))
		phandu = bg(phandu, dg);
	while ((dc > 0) && (phandu >= pow(dc, 2)))
		phandu = bc(phandu, dc);
	return phandu;
}

double Sun(int nep, int dc, int dg)
{
	int z = ld[0] % 5, w = dc % 6;
	nep = nep + (nep * y[w][z] / 100.0);
	ld[0] = ld[0] - y[w][z];
	if (((dg + dc) % 3) == 0)
		return Rain(nep, dc, dg);
	else if (((dg + dc) % 3) == 1)
		return Wind(nep, dc, dg);
	else
		return Cloud(nep, dc, dg);
}

double nepduthaydoitheothoitiet(char thoitiet[])
{
	if (strcmp(thoitiet, "Rain") == 0)
		return Rain(x[0], x[1], x[2]);
	else
	{
		if (strcmp(thoitiet, "Wind") == 0)
			return Wind(x[0], x[1], x[2]);
		else
		{
			if (strcmp(thoitiet, "Cloud") == 0)
				return Cloud(x[0], x[1], x[2]);
			else
			{
				if (strcmp(thoitiet, "Fog") == 0)
					return Fog(x[0], x[1], x[2]);
				else
					return Sun(x[0], x[1], x[2]);
			}
		}
	}
}

int main()
{
	double phandu;
	char thoitiet[10];
	FILE *finp, *fout;
	finp = fopen("input.inp", "r");
	if (finp != NULL)
	{
		fscanf(finp, "%d %d %d %d %s", &x[0], &x[1], &x[2], &ld[0], &thoitiet);
		fclose(finp);
	}
	phandu = nepduthaydoitheothoitiet(thoitiet);
	fout = fopen("output.out", "w");
	if ((x[0] > 1000) || ((ld[0] < 1) && (ld[0] > 200)))
		fprintf(fout, "-1 -1 %d", x[0]);
	else
	{
		if (((strcmp(thoitiet, "Cloud") == 0) && (sobanbe(x[0]) == 1)) || (((x[1]) < 0) && (x[2] < 0)))
			fprintf(fout, "%.3f", phandu);
		else
		{
			if (x[1] < 0)
				fprintf(fout, "%d %.3f", banh[1], phandu);
			else
			{
				if (x[2] < 0)
					fprintf(fout, "%d %.3f", banh[0], phandu);
				else
					fprintf(fout, "%d %d %.3f", banh[0], banh[1], phandu);
			}
		}
	}
	fclose(fout);
}